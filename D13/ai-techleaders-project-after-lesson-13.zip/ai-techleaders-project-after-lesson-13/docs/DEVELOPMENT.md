# 🛠️ DevMentor — development guide

Everything you need to run, configure, test and understand DevMentor locally. The
[README](../README.md) covers what the product does; this page covers how it works.

> Working in this repository as a human or an AI agent? Read
> **[AGENTS.md](../AGENTS.md)** as well — it documents the conventions and the gotchas
> that cost us time the first way around.

## Contents

- [Setup](#setup)
  - [Bring your own PostgreSQL](#bring-your-own-postgresql)
  - [Manual setup](#manual-setup)
  - [What to open](#what-to-open)
- [Configuration](#configuration)
  - [Application](#application)
  - [Database](#database)
  - [Authentication](#authentication)
  - [Signing in](#signing-in)
  - [Mail](#mail)
  - [Payments](#payments)
  - [Integration-test doubles](#integration-test-doubles)
  - [Missing, dangerous, and required-in-production](#missing-dangerous-and-required-in-production)
  - [Creating a GitHub OAuth app](#creating-a-github-oauth-app)
- [Production deployment](#production-deployment)
  - [Dokploy with Docker Compose](#dokploy-with-docker-compose)
  - [Railway](#railway)
- [Scripts](#scripts)
- [Testing and pull-request checks](#testing-and-pull-request-checks)
- [Releases](#releases)
- [Architecture](#architecture)

## Setup

Requires **Node ≥ 24**. Docker is optional — see
[Bring your own PostgreSQL](#bring-your-own-postgresql).

```bash
npm install
npm run setup
npm run dev
```

`npm run setup` does everything the manual steps below do: installs workspace
dependencies, creates `.env` from `.env.example`, makes sure a PostgreSQL is running,
applies migrations, and seeds a sample mentor.

It is **idempotent** — run it as often as you like. Every step checks whether it is
already done and reports itself as `ran` or `skipped`, so a second run only does the
work that is actually outstanding:

```text
✔ Preflight (ran) — Node v24.10.0
↷ Install dependencies (skipped) — node_modules is up to date with package-lock.json
↷ Configure .env (skipped) — .env already exists and sets every documented variable
✔ Start PostgreSQL (ran) — docker compose up -d postgres
✔ Wait for PostgreSQL (ran) — container reports healthy
✔ Apply migrations (ran) — npm run db:migrate
✔ Seed sample data (ran) — npm run db:seed
```

Your existing `.env` is never overwritten. If it is missing a variable that
`.env.example` documents, setup leaves the file alone and warns you which key to add.
Setting `DATABASE_URL` counts as setting the discrete `DB_HOST`, `DB_PORT`, `DB_NAME`,
`DB_USER`, and `DB_PASSWORD` variables it replaces, so the URL style is never reported
as incomplete.
Setup deliberately stops short of starting the app — `npm run dev` never exits — and
prints it as the next command instead.

### Bring your own PostgreSQL

**Docker is only a fallback.** Setup first checks whether anything is already
listening at the address the app is configured to use, and reuses it if so — a
container you started yourself, a native PostgreSQL install, or a managed remote
database. Docker Compose is consulted only when nothing answers, and only then does
its absence become an error.

To point setup at an existing database, set `DATABASE_URL` (or the discrete `DB_*`
variables) in your environment or in `.env`:

```bash
DATABASE_URL=postgres://user:password@db.example.com:5432/devmentor npm run setup
```

```text
↷ Provision PostgreSQL (skipped) — something is accepting connections on
  db.example.com:5432 (per DATABASE_URL from the environment) — reusing it as the
  DevMentor database; Docker not needed
```

The check is a TCP probe, so it can tell that *something* is listening but not that it
speaks PostgreSQL. If the listener turns out not to be your DevMentor database, the
`Apply migrations` step below it reports the real connection error.

Resolution order matches the Zod config modules: `DATABASE_URL` wins over
`DB_HOST`/`DB_PORT`, and the real environment wins over `.env`. With no database
reachable *and* no Docker, setup stops and names both remedies rather than failing
with a stack trace.

### Manual setup

The individual steps, if you would rather run them yourself or need to deviate:

```bash
# 1. Install (links all workspaces)
npm install

# 2. Configure — copy the example and adjust if needed
cp .env.example .env

# 3. Start Postgres (defaults match .env)
npm run db:up

# 4. Create the schema and seed a sample mentor
npm run db:migrate
npm run db:seed

# 5. Run the app
npm run dev
```

Note that step 4 races the container's startup on a cold `db:up`; wait for
`docker compose ps` to report `healthy` before migrating. `npm run setup` handles that
wait for you.

### What to open

- <http://localhost:3000> — public landing page (Tailwind).
- <http://localhost:3000/mentor> — the mentor workspace (profile, prices, times); a
  mentor's public page appears at `/m/<slug>` once they publish it.
- <http://localhost:3000/home> — the signed-in mentee home.
- <http://localhost:3000/admin> — admin dashboard (shadcn-ui).
- <http://localhost:3000/admin/users> — users list, read through the DI container.
- <http://localhost:3000/api/health> — app + database health JSON.

The app **builds and boots even with no database running**; DB-backed pages degrade
to a visible "unavailable" state instead of crashing.

## Configuration

Every variable is declared in `.env.example` and validated by a zod schema —
`packages/core/src/config/env.ts` for the app, `packages/db/src/env.ts` for the
MikroORM CLI. Nothing under `packages/` reads `process.env` directly.

### Application

| Variable | Default | What it does |
| --- | --- | --- |
| `NODE_ENV` | `development` | `development`, `test`, or `production`. |
| `APP_NAME` | `DevMentor` | Name attached to every log line. |
| `LOG_LEVEL` | `info` | pino level, from `fatal` to `silent`. |
| `APP_URL` | `http://localhost:3000` | Absolute origin of this deployment. Builds the OAuth redirect URI and the links in outbound mail, so it must be the address a browser actually reaches. Must be `http://` or `https://`. |
| `TRUSTED_PROXY_HOPS` | `0` | How many reverse proxies sit in front of the app. The rate limiter takes the client IP this many hops from the right of `x-forwarded-for`; `0` trusts no forwarded header, so per-IP limiting is off and only the per-email limits apply (a warning says so once per process). Counting from the right is deliberate: a proxy appends to the header, so a value a client forged always sits to the left of the one infrastructure wrote. |
| `INVITATION_TTL_DAYS` | `14` | Days a newly created mentor invitation remains valid. Snapshotted when the invitation is created. |
| `MENTOR_PUBLISH_WINDOW_DAYS` | `14` | Days an accepted mentor has to publish a bookable session. Snapshotted at acceptance. |
| `PLATFORM_CURRENCY` | `PLN` | Fixed platform currency for mentor prices. The first release rejects every other currency. |
| `PLATFORM_PRICE_BOUNDS` | `{"25":{"minCents":9000,"maxCents":60000},"50":{"minCents":18000,"maxCents":120000}}` | Integer-cent inclusive bounds for 25- and 50-minute sessions. Must be valid JSON in the exact documented shape and no longer than 256 characters. |
| `PLATFORM_FEE_PERCENT` | `20` | DevMentor's share of a paid session, in whole percent (0-100). The fee **in force when a payment is confirmed** is snapshotted onto that booking, so changing this affects later sessions only. |

### Database

| Variable | Default | What it does |
| --- | --- | --- |
| `DATABASE_URL` | *(unset)* | Full connection URL. Takes precedence over every `DB_*` variable it replaces. |
| `DB_HOST` / `DB_PORT` | `127.0.0.1` / `5432` | Discrete connection, used when `DATABASE_URL` is unset. |
| `DB_NAME` / `DB_USER` / `DB_PASSWORD` | `devmentor` | Discrete connection, as above. Defaults match `docker-compose.yml`. |
| `DB_POOL_MIN` / `DB_POOL_MAX` | `2` / `10` | Connection pool bounds. Not implied by `DATABASE_URL`. |
| `DB_POOL_IDLE_MS` | `30000` | How long an idle pooled connection is kept. |
| `DB_DEBUG` | `false` | `true` logs every SQL statement. |

### Authentication

| Variable | Default | What it does |
| --- | --- | --- |
| `SESSION_SECRET` | *(unset)* | Signs every session cookie and every short-lived purpose token. At least 32 characters — a shorter value is rejected at boot. Generate one with `openssl rand -base64 32`. |
| `SESSION_SECRET_PREVIOUS` | *(unset)* | The outgoing secret during a rotation. Accepted on verify, never used to sign, so live sessions survive their remaining lifetime. Same 32-character minimum. |
| `GITHUB_CLIENT_ID` | *(unset)* | GitHub OAuth app client ID — see below. |
| `GITHUB_CLIENT_SECRET` | *(unset)* | GitHub OAuth app client secret. |
| `PASSWORD_HASH_CONCURRENCY` | `2` | How many `scrypt` hashes may run at once in this process. The bound is memory, not CPU: at the parameters this project fixes (N=2¹⁷, r=8, p=1) one hash holds 128 MiB for its whole duration, so `2` caps the hashing path at ~256 MiB. It cannot be unbounded, because the rate limiter in front of it is keyed per IP *and* per email rather than globally. Raising it past `UV_THREADPOOL_SIZE` (4 by default) buys queueing inside libuv rather than more parallelism. |
| `PASSWORD_HASH_WAIT_MS` | `2000` | How long a request waits for a free hashing slot before the gate answers `503 service_unavailable`. That 503 is deliberately raised *before* the rate limiter is consumed, so a burst cannot lock out users who were merely unlucky. `0` means never queue. |
| `OPERATOR_EMAILS` | *(empty)* | Comma-separated founder addresses. Operator authority is derived from this list on **every** request and matched, trimmed and case-insensitively, against the account's verified email — so removing an address takes effect on that person's very next request rather than at their next sign-in. |

### Signing in

Two methods, one session. **GitHub is the primary one** and is the first action on
`/sign-in` and `/register`; the email form below it posts to `POST /api/auth/login` and
`POST /api/auth/register`.

Registration writes the account immediately but issues **no** session: `email_verified_at`
is what allows a sign-in, and only the link mailed by `GET /api/auth/verify-email` sets it.
Opening that link confirms the address and signs the browser in on the same redirect.
There is no resend route — registering the same address again re-claims the unconfirmed row
and sends a fresh link.

Locally, with `MAILER_ADAPTER` unset in development, the log mailer is selected
automatically and the link is written to the app's own output as a `mail.sent` line
carrying `to`, `subject` and `text`. So: register in the browser, find that line in the
`npm run dev` output, and open the URL in it.

Two seeded personas carry a password as well as a GitHub identity —
`mock-mentee@devmentor.test` and `mock-operator@devmentor.test`, one unprivileged and one
privileged, so the form-based sign-in scenarios can reach both a mentee surface and
`/admin` without GitHub. It is `SEED_PASSWORD` in
`packages/db/src/seeders/seed-password.ts` — published, obviously fake, and useless
anywhere real. `mock-mentor@devmentor.test` is deliberately password-less: it is the
account a *mock GitHub* sign-in resolves to, and it keeps a live example of the
GitHub-only row shape that `registerWithPassword` must answer with a 409.

Sign-in and registration are rate-limited per IP and per email address (10 and 5 per 15
minutes for sign-in, 5 per hour for registration). Tripping a limit answers `429` with
`Retry-After`; the counters live in `auth_rate_limits`, so they survive a restart. Behind a
proxy, set `TRUSTED_PROXY_HOPS` so the client IP is read from the right position in
`x-forwarded-for` — with it unset, the per-IP bucket is skipped and only the per-email one
applies.

### Mail

`MAILER_ADAPTER=resend` plus `MAIL_API_KEY` and `MAIL_FROM` deliver for real. Development
falls back to the log mailer described above; a production deployment without a key fails
at container creation rather than serving a registration form that always 503s.

| Variable | Default | What it does |
| --- | --- | --- |
| `MAILER_ADAPTER` | *(unset)* | `resend` for real delivery. Left unset in development the log mailer will be selected on its own; `log` set explicitly is refused outside an integration run (below). |
| `MAIL_API_KEY` | *(unset)* | Resend API key. |
| `MAIL_FROM` | *(unset)* | Envelope sender, e.g. `DevMentor <hello@devmentor.example.com>`. |

### Payments

Stripe is the only payment provider: Checkout for sessions, Connect for mentor payouts.
Both keys are optional and **fail closed at the point of use** - a deployment without them
builds, boots and serves every page, and answers 503 from the Checkout and webhook routes.

**A missing key never selects the mock gateway.** `PAYMENT_GATEWAY` does that, and only
with a second signal: `mock` is accepted in an integration run (`INTEGRATION_TEST_RUN=1`)
and picked up automatically when the variable is unset in development. Anywhere else — a
production deployment that has not been given its Stripe key yet, say — the real adapter is
registered and the pay button answers 503. That is a bug report; selecting the mock instead
would give every session away, because it returns the caller's own success URL and its
webhook secret is a constant in this repository.

| Variable | Default | What it does |
| --- | --- | --- |
| `PAYMENT_GATEWAY` | *(unset)* | `stripe` or `mock`. Unset means the mock in development and Stripe everywhere else. `mock` outside development needs `INTEGRATION_TEST_RUN=1` or the app refuses to boot. |
| `STRIPE_SECRET_KEY` | *(unset)* | Secret API key from the Stripe dashboard. Without it the Checkout route answers 503. |
| `STRIPE_WEBHOOK_SECRET` | *(unset)* | Signing secret for the endpoint you point at `POST /api/payments/webhook`. Without it that route refuses every delivery. |

`POST /api/payments/webhook` is the one route in the product that does not answer the
`{ ok, data }` envelope and the only one that skips the CSRF header: the caller is Stripe,
not a browser, and it authenticates by signing the raw request body. A booking becomes
`confirmed` only from a verified delivery - returning from Checkout proves nothing.

### Integration-test doubles

Set by `tests/integration/environment.ts`, never on a real deployment.

| Variable | Default | What it does |
| --- | --- | --- |
| `AUTH_IDENTITY_ADAPTER` | *(unset)* | `github` for real sign-in, `mock` for the harness double. |
| `INTEGRATION_TEST_RUN` | *(unset)* | The literal `1` marks the process as an integration-test run, which is what permits a `mock` or `log` adapter. |

### Missing, dangerous, and required-in-production

The three categories behave differently on purpose:

- **Missing integration credentials fail closed at the route.** With no
  `GITHUB_CLIENT_ID`/`GITHUB_CLIENT_SECRET`, `/api/auth/github` redirects the browser to
  `/sign-in?error=unavailable`, where the page says sign-in is temporarily unavailable.
  Everything else — the marketing pages, the build, the boot — carries on. One
  unconfigured integration never takes the site down.
- **Dangerous configuration fails at boot, loudly.** `AUTH_IDENTITY_ADAPTER=mock`
  replaces GitHub sign-in with a fake identity, and `MAILER_ADAPTER=log` writes email
  to the application log instead of delivering it. Either one without
  `INTEGRATION_TEST_RUN=1` — and only the literal `1` counts — makes the process refuse
  to start. The alternative, silently falling back to the real adapter, would leave an
  operator believing the mock is active when it is not.
- **Production requires `SESSION_SECRET` at boot.** A production deployment without the
  secret that signs every session cookie must not come up green and then fail every
  sign-in. The check runs at first container creation, **not** in the zod schema,
  because `npm run build` forces `NODE_ENV=production` and CI builds with no
  environment at all; the container is only ever created while serving a request.
  Development is unaffected — `npm run dev` starts without a secret, and sign-in fails
  closed until you set one.

The integration harness supplies its own database URL, session secret and test-double
signals (`tests/integration/environment.ts`); you do not need any of them in a local
`.env`.

### Creating a GitHub OAuth app

1. Go to **Settings → Developer settings → OAuth Apps → New OAuth App**
   (<https://github.com/settings/developers>).
2. **Application name** — anything; it is shown on the consent screen.
   **Homepage URL** — your `APP_URL`.
   **Authorization callback URL** — `<APP_URL>/api/auth/github/callback`, so
   `http://localhost:3000/api/auth/github/callback` for local development. GitHub
   matches this exactly, and a mismatch is the usual cause of a failed sign-in.
3. Register the app, copy the **Client ID**, then **Generate a new client secret** and
   copy that too — GitHub shows it once.
4. Put both in `.env` as `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET`, and set
   `SESSION_SECRET` alongside them. Use a separate OAuth app per environment; the
   callback URL is per-app, so local and production cannot share one.

## Production deployment

The root [`Dockerfile`](../Dockerfile) is the production image for both Dokploy and
Railway. It installs from `package-lock.json`, builds the complete npm workspace, runs
as the unprivileged `node` user, and starts Next on `0.0.0.0`. After the build it
prunes development dependencies, retaining only the MikroORM CLI, `tsx`, `dotenv`, and
TypeScript migration sources needed to run migrations from the same release image.

The container runs `npm run deploy:preflight` before Next. This validates the
production session and mail secrets without connecting to PostgreSQL, preventing a
misconfigured release from passing the HTTP health check and failing only on its first
authentication request.

Do not set `AUTH_IDENTITY_ADAPTER=mock`, `MAILER_ADAPTER=log`, or
`INTEGRATION_TEST_RUN=1` on a real deployment. Do not run `npm run db:seed` in
production.

### Dokploy with Docker Compose

Use [`docker-compose.deploy.yml`](../docker-compose.deploy.yml), not the local
`docker-compose.yml`. The deployment definition keeps PostgreSQL private, stores its
data in a named volume, runs migrations as a one-shot service after PostgreSQL is
healthy, and starts the app only after migrations succeed.

1. In the target Dokploy project and environment, create a **Docker Compose** service,
   choose the repository provider and production branch, and set **Compose Path** to
   `./docker-compose.deploy.yml`.
2. Copy the keys from [`deploy.env.example`](../deploy.env.example) into the service's
   Environment editor. Supply strong, unique values for every blank required setting.
   `APP_URL` must be the final HTTPS origin and `SESSION_SECRET` must contain at least
   32 random characters. Dokploy writes these values to the Compose project's `.env`;
   the deployment file explicitly passes only the variables each container needs.
3. Enable **Isolated Deployments**. In Dokploy's Domains tab, route the public domain
   to service `app` on container port `3000`; Dokploy will add the Traefik routing and
   TLS configuration.
4. Preview the resolved Compose definition and confirm that only `app` is routed
   publicly. Deploy, then check that `postgres` is healthy, `migrate` exited with code
   0, and `app` is healthy in Dokploy.
5. Open `<APP_URL>/api/health` and confirm that the JSON contains `status: "ok"` and
   `database: "up"` before exercising registration and sign-in. HTTP 200 alone is not
   enough: the route remains reachable while reporting a database outage in its body.

Dokploy's native Domains feature and Isolated Deployments are the intended network
setup; do not add host port mappings or fixed `container_name` values. Dokploy injects
the Traefik routing for service `app`, while `postgres` remains reachable only inside
the Compose network.

For a direct Traefik-to-app path, `TRUSTED_PROXY_HOPS=1` is the expected starting
value. Add one for each additional trusted proxy, such as Cloudflare, only after
checking the actual `x-forwarded-for` chain. The value is a security boundary, not a
generic "behind a proxy" switch.

For a local smoke test of the same stack, copy the example to the git-ignored
`deploy.env`, fill it, and run:

```sh
docker compose --env-file deploy.env -f docker-compose.deploy.yml up --build -d
docker compose --env-file deploy.env -f docker-compose.deploy.yml ps
```

The named volume makes database storage persistent; it is not a backup. Configure and
test scheduled PostgreSQL backups in Dokploy before storing production data, and plan
major PostgreSQL upgrades separately rather than changing the image tag in place.

To rotate the session signing key without immediately invalidating live sessions,
move the current `SESSION_SECRET` value to `SESSION_SECRET_PREVIOUS`, set a new random
`SESSION_SECRET`, and redeploy. Remove `SESSION_SECRET_PREVIOUS` after the old sessions
have expired. Do not define it as an empty string: when no rotation is in progress,
leave the variable absent.

### Railway

Railway detects the root `Dockerfile` automatically. Its legacy
`railway.json`/`railway.toml` Config-as-Code format is deprecated, so provider state is
not committed in that format. Configure the service in Railway as follows:

1. Create a project with a managed PostgreSQL service and an application service from
   this repository. Keep the application root at the repository root so Railway finds
   the Dockerfile and every workspace.
2. Set `DATABASE_URL` on the app to `${{Postgres.DATABASE_URL}}`. Also set
   `NODE_ENV=production`, `DB_MIGRATIONS_SNAPSHOT=false`, `APP_URL`,
   `SESSION_SECRET`, `MAIL_API_KEY`, and `MAIL_FROM`. Add GitHub credentials and
   `OPERATOR_EMAILS` when those features should be available. Never copy local test
   adapter flags.
3. Set the app's **Pre-deploy Command** to `npm run db:migrate`. Keep
   `DB_MIGRATIONS_SNAPSHOT=false` as the service variable from step 2; Railway's
   pre-deploy executor does not treat a leading shell-style assignment as an
   environment override. A failed migration then stops the release before the web
   container changes.
4. Leave the start command unset so Railway uses the image `CMD`. Generate or attach
   the public domain, update `APP_URL` to that exact HTTPS origin, and set the health
   path to `/api/health`.

Railway injects `PORT`; Next honors it automatically. Railway treats `/api/health` as
a rollout liveness check because it only considers the HTTP status; the route returns
HTTP 200 even when its JSON reports `database: "down"`. The Dokploy Compose healthcheck
is stricter and also requires that JSON field to be `"up"`. Railway does not use its
health path as continuous monitoring after deployment. The pre-deploy migration proves
database access during rollout; configure separate uptime and database monitoring for
ongoing operations.

Password hashing uses about 128 MiB per in-flight hash. With the default
`PASSWORD_HASH_CONCURRENCY=2`, give the app substantially more than 256 MiB of memory
for Next, the ORM, and request headroom, or deliberately lower the concurrency setting.

## Scripts

| Command | Description |
| --- | --- |
| `npm run setup` | One-command install, configure, database up, migrate, and seed (idempotent; reuses an existing PostgreSQL, Docker only as fallback) |
| `npm run dev` | Start the Next.js dev server |
| `npm run build` / `npm run start` | Production build / serve |
| `npm run typecheck` | `tsc --noEmit` across all packages |
| `npm run lint` | ESLint, including dependency-direction rules |
| `npm run test:unit` | Run TypeScript unit tests with Vitest |
| `npm run test:unit:coverage` | Run unit tests with per-file 100% coverage gates |
| `npm run storybook` | Build the prototype and start the local component catalogue |
| `npm run build-storybook` | Build the prototype and the static component catalogue |
| `npm run prototype` | Rebuild the clickable journey preview from `prototypes/devmentor-journey/` |
| `npm run test:browser:install` | Install agent-browser's Chrome runtime locally |
| `npm run test:integration` | Test an ephemeral PostgreSQL + production app with agent-browser. Set `AGENT_BROWSER_CDP=<port or ws:// url>` to attach to a Chrome you started yourself, for a machine that cannot launch the bundled one. |
| `npm run payouts:run` | Pay every mentor whose session has finished. Safe to run twice - one payout per session is enforced by a unique index - and the same action the operator dashboard offers. |
| `npm run invite -- create <email> --operator <label> --tags TypeScript,React [--batch <label>]` | Create a single-use mentor invitation. The audit line is token-free; the link is printed separately once. |
| `npm run invite -- revoke <id> --operator <label>` | Revoke a pending mentor invitation. |
| `npm run invite -- resend <id> --operator <label>` | Rotate a pending invitation token and expiry, then print the new link separately. |
| `npm run db:up` / `npm run db:down` | Start / stop local Postgres (Docker) |
| `npm run db:migration:create -- --name <x>` | Generate a migration from entity diff |
| `npm run db:migrate` / `npm run db:migrate:down` | Apply / revert migrations |
| `npm run db:seed` | Run the default seeder |
| `npm run db:seed:sessions` | Plant six confirmed text-session fixtures for manual QA — one before its start, one open now, one ended with the written answer still owed, one ended with it posted, one with a note sent for approval, one with a note the mentee declined. Needs `db:seed` first, is safe to re-run, and is never part of `db:seed` |

## Testing and pull-request checks

Every pull request runs four independent GitHub checks: **Build**, **Lint**, **Unit
tests**, and **Integration tests**. Configure those exact names as required checks in
the GitHub branch ruleset if merges must be blocked until they pass.

The unit suite uses Vitest and V8 coverage:

```bash
npm run test:unit
npm run test:unit:coverage
```

Coverage is enforced at 100% for statements, branches, functions, and lines on every
file listed in `vitest.config.mts`. New features must add their production files to
that explicit list and add adjacent unit tests in the same change.

The integration suite requires Docker and agent-browser's Chrome runtime. Install the
browser once, then run the suite:

```bash
npm run test:browser:install
npm run test:integration
```

The suite creates a fresh PostgreSQL 17 Testcontainer on a random port, applies
migrations, seeds prerequisites, builds and starts Next.js on another random port,
waits for database readiness, then tests the home page and admin panel through the
pinned `agent-browser` CLI. Screenshots and app logs go to `test-results/integration/`;
the browser, app process, and container are stopped in teardown. POSIX and native
PowerShell launchers are also available at `tests/integration/run.sh` and
`tests/integration/run.ps1`.

## Releases

Prepare a complete `# <version> (YYYY-MM-DD)` section in `CHANGELOG.md`, merge it to
`master`, then run **Actions → Release DevMentor → Run workflow** from `master`. Choose
`patch`, `minor`, or `major`, or choose `custom` and enter an exact stable version such
as `1.4.0`. The custom field must stay empty for the three automatic bumps.

The workflow validates the repository, updates the root and all workspace package
versions plus `package-lock.json`, commits the bump, and atomically pushes that commit
with an annotated `v<version>` tag. It then publishes a GitHub Release using only that
version's changelog section. Repository rules must allow the workflow's `GITHUB_TOKEN`
to push this release commit to the default branch.

If publication fails after the commit and tag were pushed, rerun the workflow from
`master` with `custom` and the same current version. Recovery proceeds only when the
existing annotated tag belongs to the current `master` history, its tagged manifests,
lockfile, and changelog agree, and no GitHub Release exists. Recovery publishes from
that immutable tagged commit even if newer changes have since reached `master`; tags
are never moved or replaced.

## Architecture

### Monorepo packages

The repo is an npm-workspaces monorepo under `packages/*` with a strictly one-way
dependency graph (enforced by ESLint — a cycle fails `npm run lint`):

```
app ──> core ──> db
 └────> ui
```

| Package | Name | Responsibility |
| --- | --- | --- |
| `packages/app` | `@devmentor/app` | Next.js host and **composition root** — the only package allowed to import all others. Contains routes, layouts, and API handlers. |
| `packages/core` | `@devmentor/core` | Config (zod), logging (pino), the **awilix DI container**, and domain services. Depends on `db`; never touches React/Next/UI. |
| `packages/db` | `@devmentor/db` | MikroORM configuration, entities, migrations, seeders. The **leaf** — the only package that imports `@mikro-orm/*`. |
| `packages/ui` | `@devmentor/ui` | shadcn-ui components and Tailwind design tokens. Presentational only. |

Packages are consumed as **TypeScript source** (no per-package build) and transpiled
by Next.js via `transpilePackages`.

### Dependency injection

`@devmentor/core` builds a single awilix container (`PROXY` injection mode, a typed
`Cradle` interface). Lifetimes:

- **Singleton** — `env`, `logger`, `orm` (cached on `globalThis` to survive HMR).
- **Scoped** — a forked `EntityManager` and the domain services that use it.

Request handlers call `withScope(fn)`, which opens a scope with its own forked
`EntityManager`, runs the callback, and disposes the scope. The admin users page is a
worked example: `withScope((c) => c.userService.list())` → forked EM → repository →
entity with a populated 1:1 relation.

### Reusable API and UI layers

No route hand-rolls fetch, validation, authorization or error handling:

- `packages/core/src/http/` — the typed `AppError` hierarchy, `apiHandler` (maps
  errors to a `{ ok, data }` / `{ ok, error }` envelope and requires the CSRF header on
  every mutating verb), `makeCrudRoute` (schema + service in, `{ GET, POST, PUT, DELETE }`
  out) and the `requireSession` / `requireRole` guards.
- `packages/ui/src/backend/` — `apiCall` (the only sanctioned `fetch()` call site),
  `CrudForm`, `DataTable`, and the loading/error/empty feedback components.

### Database

- MikroORM v7 with the PostgreSQL driver, explicit connection pooling, and migrations
  under `packages/db/migrations`.
- Entities are defined with `defineEntity` (MikroORM v7 dropped decorators) and
  registered as `globalThis` singletons so the same schema object is shared across
  Next's RSC/SSR/route module graphs.

### Frontend / backend split

- **Public / marketing pages** (`/`, `/m/<slug>`, `/invitation/<token>`, `(auth)/*`)
  use plain Tailwind CSS v4 utilities.
- **Signed-in surfaces** (`(mentee)/*`, `(mentor)/*`, `/admin/*`) use shadcn-ui
  components from `@devmentor/ui` inside `AppShell`. The design tokens live in
  `packages/ui/src/tokens.css`; add components with `npx shadcn@latest add <component>`
  run inside `packages/ui`.

### Spec-driven development

Nontrivial work is specified before it is built. Specs, autonomous-run logs, and
lessons live under `.ai/` — see [AGENTS.md](../AGENTS.md) for the full workflow and
[SDLC.md](../SDLC.md) for how a change travels from ticket to merge.
