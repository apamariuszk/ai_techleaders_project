# Run: bump non-major dependencies to clear the critical next/og advisory

- Issue: #71
- Branch: `fix/bump-non-major-deps`
- Skill: `om-auto-create-pr`

## Goal

Clear the critical `next/og` RCE advisory (`next` 16.3.3) and the three high transitive
advisories by moving every non-major dependency gap named in #71 to its latest
non-major version, touching only `package.json` files and `package-lock.json`.

## Scope

- `next` + `eslint-config-next` → 16.3.8 (kept in step).
- `react` / `react-dom` → 19.3.0; `@types/react` / `@types/react-dom` → 19.3.0.
- `@mikro-orm/*` → 7.2.3 (one set).
- `storybook` + `@storybook/*` → 10.6.1 (one set).
- `zod` → 4.6.5 (core, db, ui), `vite` 8.3.2, `msw-storybook-addon` 3.0.3,
  `lucide-react` 1.49.0, `tailwind-merge` 3.7.0, `@testcontainers/postgresql` 12.2.0,
  `agent-browser` 0.38.1, `tsx` 4.23.15.
- Transitive `undici`, `brace-expansion`, `@grpc/grpc-js` via `npm audit fix` (no `--force`).
- Keep each manifest's pin style (exact where exact, caret where caret).

## Non-goals

- Majors: `typescript` 7, `eslint` 10, `vitest`/`@vitest/coverage-v8` 5, `jsdom` 30,
  `msw` 3, `dotenv` 18, `@types/node` 26.
- Dependabot/Renovate, changing the exact-pin policy, adding `npm audit` to the gate.
- Any production source change not strictly forced by a dependency.

## Implementation Plan

### Phase 1: Bump

1. Edit manifests and regenerate the lockfile with one `npm install`.
2. Run `npm audit fix` (non-force) for remaining transitive advisories; confirm zero
   critical/high.

### Phase 2: Verify

1. Gate: `typecheck`, `lint`, `test:unit:coverage`, `build`.
2. Storybook + prototype: `typecheck:storybook`, `typecheck:prototype`, `build-storybook`.
3. `test:integration` (TC-DB-001 empty entity↔migration diff); `devmentor.json` unchanged.

## Risks

- MikroORM 7.1 → 7.2 minor may change metadata/diff behavior — covered by TC-DB-001.
- React 19.3 / Storybook / lucide may shift jsdom tests or rendered output.

## Progress

PR: #78

> Convention: `- [ ]` pending, `- [x]` done. Append ` — <commit sha>` when a step lands. Do not rename step titles.

### Phase 1: Bump

- [x] 1.1 Bump manifests and regenerate lockfile — 6454ecc
- [x] 1.2 Resolve transitive advisories with npm audit fix — 5e9ae9f

### Phase 2: Verify

- [x] 2.1 Run typecheck, lint, unit coverage and build — 8eb852f
- [x] 2.2 Run storybook and prototype checks — 8eb852f
- [x] 2.3 Run integration suite — 8eb852f
- [x] Post-review fix: keep root package description escape unchanged — 1cb6715
