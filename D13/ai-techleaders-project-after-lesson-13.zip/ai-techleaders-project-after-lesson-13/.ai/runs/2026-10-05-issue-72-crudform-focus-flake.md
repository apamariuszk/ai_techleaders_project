# 2026-10-05 — Issue #72: flaky CrudForm focus assertion

## Requested

`om-auto-fix-issue 72`: make `CrudForm > focuses returned server field errors and a
general failure after requests finish` fail only when the component is broken.

## Done

- Triage (`om-verify-in-repo`): real and unfixed on `origin/master` (`cc376c0`); no PR or
  commit references #72.
- Root cause (`om-root-cause`): `CrudForm.test.tsx:143` asserted `document.activeElement`
  synchronously after `await screen.findByText('Try again later.')`. `findByText`
  resolves when the alert node is committed; focus moves later, in the passive effect at
  `CrudForm.tsx:212-218`.
- Fix (`om-fix`): line 143 now awaits the focus with `waitFor`, matching line 139.
  `CrudForm.tsx` is unchanged.

## Evidence

- Deterministic reproduction: with the focus effect temporarily changed to
  `setTimeout(() => target?.focus(), 0)` (local only, reverted), the pre-fix test fails
  with the CI message (`expected <input …> to be <p role="alert" …>`) and the fixed test
  passes.
- Natural reproduction under CPU load (`.ai/lessons.md`, 2026-09-03), 18-core machine:

  | Load | Pre-fix file | Fixed file |
  | ---- | ------------ | ---------- |
  | 8 busy loops | 30/30 passed | 30/30 passed |
  | 24 busy loops | 39/40 passed (1 failure) | 30/30 passed |

  Loop: `for i in $(seq 24); do (while :; do :; done) & done`, then
  `npx vitest run packages/ui/src/backend/forms/<file>` N times, then `kill $(jobs -p)`.
  The pre-fix file was run as a temporary copy of `origin/master`'s test, deleted afterwards.
- Gate: `npm run typecheck`, `npm run lint`, `npm run test:unit:coverage` (210 files,
  2371 tests, per-file 100% thresholds hold), `npm run build` — all exit 0.

## Notes

- `CrudForm.user-event.test.tsx:167` has a similar shape but stayed green with the focus
  effect delayed, so it was left alone per the issue's scope.
- The `queueMicrotask` timezone effect (`CrudForm.tsx:205-210`) did not surface in any loop.
