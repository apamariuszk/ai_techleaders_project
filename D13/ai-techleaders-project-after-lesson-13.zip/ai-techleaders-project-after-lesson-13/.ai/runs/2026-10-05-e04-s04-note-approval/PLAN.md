# Plan — E04-S04 Phase 3: approve, decline, redraft, and the decline count (#29)

**Source doc:** `.ai/specs/2026-10-01-sessions-notes.md` (Phase 3 only)
**Branch:** `feat/e04-s04-note-approval` → stacked PR with base `feat/e04-s03-session-note` (PR #81)
**Depends on:** #81 (itself on #79) · **Closes:** #29

## Tasks

| Phase | Step | Title | Exec | Status | Commit |
| --- | --- | --- | --- | --- | --- |
| 3 | 3.1 | `note-decline.schema.ts` (+ import-free `DECLINE_COMMENT_MAX` subpath) | inline | done | effa75f |
| 3 | 3.2 | `SessionNoteService` approve / decline / redraft / answer-freeze guard | inline | done | 1e52bbc |
| 3 | 3.3 | `POST /api/notes/[bookingId]/approve` and `/decline` | inline | done | c60181b |
| 3 | 3.4 | `notes.note.approved` / `notes.note.declined`, two notification kinds (+ enum CHECK migration), subscribers | inline | done | 8a3f88a |
| 3 | 3.5 | `note-panel.tsx`: Approve, Decline, quoted comment, Redraft, approved-private | inline | done | cdb91e3 |
| 3 | 3.6 | `app/admin/session-notes.tsx` + nav entry (counts only) + QA seeder states | inline | done | 57c62ee |
| 3 | 3.7 | Integration scenario (agent-browser + Testcontainers) | inline | done | fb9f1dd |
| 3 | 3.8-review-fix | Answer freeze under row locks (booking + newest note) in one transaction, plus DB-level serialization test | inline | done |  |
| 3 | 3.9-review-fix | Cut duplicated test boilerplate (shared route suite, migration subject, note-scenario fixture) for the Sonar gate | inline | done | cb973f9 491d2e9 017679b  |

## Goal
Spec Steps 3.1–3.7; acceptance criteria 9–14. Every new/changed production file in `coverage.include` at 100% per file.

## Non-goals
Phases 1–2 (PRs #79, #81). No un-approve, no export, no note list route.

## Risks
- Another enum-CHECK migration on `notifications` (additive). `risk-medium`.
- Spec stays in `.ai/specs/` — it moves to `implemented/` only after #79 and #81 merge.
