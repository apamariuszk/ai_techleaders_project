# Notify log

- 2026-10-05T00:00Z run start: Phase 2 (2.1–2.7), stacked on PR #79.
- 2026-10-05 final gate green; redundant (booking, version) index omitted: the unique already serves the read.
- 2026-10-05 independent review (fresh subagent): no blockers/majors. Fixed: draft history rows carry `updatedAt` (no empty `<time>`). Accepted minor: the note poll stops only once approved (30 s cadence) — revisit in Phase 3 with the decided states.
