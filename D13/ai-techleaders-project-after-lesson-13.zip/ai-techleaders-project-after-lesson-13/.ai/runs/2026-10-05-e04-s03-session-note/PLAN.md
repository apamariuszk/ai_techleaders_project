# Plan — E04-S03 Phase 2: the draft note sent for approval (#28)

**Source doc:** `.ai/specs/2026-10-01-sessions-notes.md` (Phase 2 only; Phase 3 is out of scope)
**Branch:** `feat/e04-s03-session-note` → stacked PR with base `feat/e04-s02-written-answer` (PR #79)
**Depends on:** #79 · **Closes:** #28

## Tasks

| Phase | Step | Title | Exec | Status | Commit |
| --- | --- | --- | --- | --- | --- |
| 2 | 2.1 | `session-note-status.ts`, `session-note.entity.ts` (+ `note-limits`), migration `notes` | inline | done | 03de566 |
| 2 | 2.2 | `note-draft.schema.ts` | inline | done | 54c4d30 |
| 2 | 2.3 | `SessionNoteService` (`getForParty`, `saveDraft`, `sendForApproval`) + container/cradle | inline | done | 995b397 |
| 2 | 2.4 | `GET`/`PUT /api/notes/[bookingId]`, `POST .../send` | inline | done | 4bfd80e |
| 2 | 2.5 | `notes.note.sent`, `note_awaiting_approval` (+ enum CHECK migration), subscriber | inline | done | f3cf1ae |
| 2 | 2.6 | `note-panel.tsx` + session screen wiring | inline | done | 84908ca |
| 2 | 2.7 | Integration scenario (agent-browser + Testcontainers) | inline | done | d01ee3d |

## Goal
Spec Steps 2.1–2.7; acceptance criteria 5–8 and 14. Migrations ship `up` and `down`; every new or
changed production file is in `coverage.include` at 100% per file.

## Non-goals
No approve/decline routes, no decline schema, no answer-freeze guard, no admin screen (Phase 3).
Names follow the spec's file table; Phase 3 stacks on this branch.

## Risks
- New table + migration (`risk-medium`). Additive only.
- Client-bundled schema must import `MAX_NOTE_LENGTH` via the import-free `@devmentor/db/note-limits`.
