# Plan — E04-S02 Phase 1: the written answer (#27)

**Source doc:** `.ai/specs/2026-10-01-sessions-notes.md` (Phase 1 only; Phases 2–3 are out of scope)
**Branch:** `feat/e04-s02-written-answer` → PR against `master`
**Closes:** #27

## Tasks

| Phase | Step | Title | Exec | Status | Commit |
| --- | --- | --- | --- | --- | --- |
| 1 | 1.1 | `writtenAnswer`/`writtenAnswerAt` on Booking + `MAX_ANSWER_LENGTH` CHECK + migration `written_answer` | inline | done | 0c52f24 |
| 1 | 1.2 | `answer-update.schema.ts` | inline | done | 65eebb3 |
| 1 | 1.3 | `TextSessionService.postAnswer` + `answer`/`answerOwed`/`viewerRole` on the session view | inline | done | a8eebe0 |
| 1 | 1.4 | `PUT /api/sessions/[bookingId]/answer` | inline | done | 041829a |
| 1 | 1.5 | `sessions.answer.posted`, `answer_posted` kind (+ enum CHECK migration), `onAnswerPosted` | inline | done | b247570 |
| 1 | 1.6 | `answer-panel.tsx` + `session-screen.tsx` wiring + `SETTLING_POLL_MS` | inline | done | 0bc5fc0 |
| 1 | 1.7 | `QaSessionSeeder`: ended session with answer, ended session owing one | inline | done | 60f85a5 |
| 1 | 1.8 | Integration scenario (agent-browser + Testcontainers) | inline | done | 94aaff9 |

## Goal
Implement exactly spec Steps 1.1–1.8. Acceptance criteria 1–4 and 14 (100% per-file unit
coverage, every new/changed production file in `coverage.include`). Migrations ship `up` and `down`.

## Non-goals
No `session_notes` table, no note routes, no answer-freeze guard, nothing from Phases 2–3.
Names are fixed by the spec's file table (downstream phases stack on this branch).

## Risks
- Migration on `bookings` (money table): additive, nullable. PR carries `risk-medium`.
- Poll cadence change in `session-screen.tsx`.
