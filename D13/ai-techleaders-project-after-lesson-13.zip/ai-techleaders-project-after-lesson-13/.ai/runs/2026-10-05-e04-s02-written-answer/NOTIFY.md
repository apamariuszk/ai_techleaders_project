# Notify — 2026-10-05-e04-s02-written-answer

> Append-only log. Every entry is UTC-timestamped. Never rewrite prior entries.

## 2026-10-05T00:00:00Z — run started
- Brief: implement spec Phase 1 (E04-S02, #27) Steps 1.1–1.8
- External skill URLs: none

## 2026-10-05T11:40:00Z — decision
- First-posting-only event: `sessions.answer.posted` is emitted only when `writtenAnswerAt` was null; replacing emits nothing (documented in `event-map.ts`).
- `answer_posted` migration `down` deletes `answer_posted` notification rows before narrowing the CHECK so rollback cannot fail on live data.
- `MAX_ANSWER_LENGTH` lives in import-free `answer-limits.ts` (exposed as `@devmentor/db/answer-limits`) and is re-exported from `booking.entity.ts`, so the client form can bundle the schema.
- The existing `ended` QA fixture already owes its answer; only an answered fixture (`qa-fixture-session-answered`) was added.

## 2026-10-05T11:50:00Z — final gate passed
- typecheck, lint, test:unit:coverage (100%), build, integration (88 tests) green. See final-gate-checks.md.
