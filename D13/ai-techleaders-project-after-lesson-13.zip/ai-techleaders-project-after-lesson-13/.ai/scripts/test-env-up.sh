#!/bin/sh
# om-prepare-test-env: generated entrypoint (contract v2)
# regenerate with: om-prepare-test-env --regenerate
# history:
#   2026-09-10 generated for isolated Next.js/PostgreSQL UI QA
#   2026-09-10 repair: retain dev build dependencies under NODE_ENV=production
#   2026-09-10 repair: share the primary install in nested worktrees so Turbopack stays inside its detected repository root
#   2026-09-10 repair: use the supported Webpack dev server in nested worktrees; Turbopack rejects both local and shared dependencies below the common Git root
#   2026-09-10 repair: detach the dev process so warm QA runs can reuse the environment
#   2026-09-10 repair: supervise the macOS app process with launchd because command sessions reap background children
#   2026-09-10 repair: pass the version-managed Node toolchain path into launchd
#   2026-09-10 repair: wait past launchd xpcproxy handoff before recording the app pid
#   2026-09-10 repair: exclude generated build output from the source-freshness reuse check
#   2026-09-10 repair: parse descriptor timestamps as UTC rather than the local timezone
#   2026-09-10 repair: stop recorded and stale same-worktree launchd process groups before starting Next
#   2026-09-24 repair: add a native-PostgreSQL + plain-background-process path for Linux hosts with no
#     Docker daemon and no launchd (feature-detected; the macOS/Docker/launchd path is untouched)
#   2026-09-24 repair: kill the whole descendant process tree (not just the recorded pid) when
#     tearing down a non-launchd app process — a bare background job shares this script's process
#     group (no job control in a non-interactive shell), so `kill "$app_pid"` alone left the actual
#     `next-server` child (npm's grandchild) running and the port still bound
set -eu

# Kills a process and every descendant, deepest first. Needed only on the non-launchd path: a
# plain backgrounded job here has no process group of its own to kill in one shot (see history).
kill_tree() {
  _kt_pid=$1
  for _kt_child in $(pgrep -P "$_kt_pid" 2>/dev/null); do kill_tree "$_kt_child"; done
  kill -TERM "$_kt_pid" 2>/dev/null || true
}

QA_DIR=.ai/qa
DESCRIPTOR="$QA_DIR/test-env.json"
BUILD_CACHE="$QA_DIR/test-env-build-cache.json"
ENV_FILE="$QA_DIR/test-env.env"
LOCK_DIR="$QA_DIR/test-env.lock"
APP_LOG="$QA_DIR/test-env-app.log"
BUILD_INPUTS="packages scripts package.json package-lock.json tsconfig.json tsconfig.base.json next.config.ts"
ARTIFACTS="node_modules"
CACHE_TTL=${TEST_ENV_CACHE_TTL_SECONDS:-600}
FORCE=0
FORCE_REBUILD=0
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=1 ;;
    --force-rebuild) FORCE_REBUILD=1 ;;
    *) echo "Unknown argument: $arg" >&2; exit 2 ;;
  esac
done

HAS_DOCKER=0
command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && HAS_DOCKER=1
HAS_LAUNCHCTL=0
command -v launchctl >/dev/null 2>&1 && HAS_LAUNCHCTL=1

mkdir -p "$QA_DIR"
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  owner_pid=$(jq -r '.pid // 0' "$LOCK_DIR/owner.json" 2>/dev/null || echo 0)
  if ! kill -0 "$owner_pid" 2>/dev/null; then
    rmdir "$LOCK_DIR" 2>/dev/null || true
    mkdir "$LOCK_DIR"
  else
    echo "Another test environment bootstrap is active (pid $owner_pid)." >&2
    exit 1
  fi
fi
printf '{"pid":%s,"source":"om-prepare-test-env","acquiredAt":"%s"}\n' "$$" "$(date -u +%FT%TZ)" > "$LOCK_DIR/owner.json"
success=0
app_pid=
container=
launch_label=
pg_data_dir=
cleanup() {
  if [ "$success" -ne 1 ]; then
    [ -z "$launch_label" ] || launchctl remove "$launch_label" >/dev/null 2>&1 || true
    [ -z "$app_pid" ] || [ "$HAS_LAUNCHCTL" -eq 1 ] || kill_tree "$app_pid"
    [ -z "$container" ] || docker rm -f "$container" >/dev/null 2>&1 || true
    [ -z "$pg_data_dir" ] || pg_ctl -D "$pg_data_dir" stop -m immediate >/dev/null 2>&1 || true
    [ -z "$pg_data_dir" ] || rm -rf "$pg_data_dir" "$pg_data_dir.log"
  fi
  rm -f "$LOCK_DIR/owner.json"
  rmdir "$LOCK_DIR" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

if [ -f "$DESCRIPTOR" ]; then
  if [ "$FORCE" -ne 1 ]; then
    status=$(jq -r '.status // ""' "$DESCRIPTOR")
    old_pid=$(jq -r '.app.pid // 0' "$DESCRIPTOR")
    base_url=$(jq -r '.baseUrl // ""' "$DESCRIPTOR")
    started_at=$(jq -r '.startedAt // ""' "$DESCRIPTOR")
    started_epoch=$(date -u -d "$started_at" +%s 2>/dev/null || TZ=UTC date -j -f '%Y-%m-%dT%H:%M:%SZ' "$started_at" +%s 2>/dev/null || echo 0)
    now_epoch=$(date +%s)
    fresh=0
    [ $((now_epoch - started_epoch)) -le "$CACHE_TTL" ] && fresh=1
    changed=$(find packages scripts package.json package-lock.json tsconfig.json tsconfig.base.json -type f \
      ! -path '*/node_modules/*' ! -path '*/.next/*' ! -path '*/coverage/*' ! -path '*/storybook-static/*' \
      -newer "$DESCRIPTOR" 2>/dev/null | head -n 1 || true)
    if [ "$status" = running ] && [ "$fresh" -eq 1 ] && [ -z "$changed" ] \
      && kill -0 "$old_pid" 2>/dev/null \
      && curl -fsS --max-time 5 "$base_url/api/health" | jq -e '.status == "ok" and .database == "up"' >/dev/null; then
      success=1
      echo "TEST_ENV_STATUS=running"
      echo "TEST_ENV_BASE_URL=$base_url"
      echo "TEST_ENV_DESCRIPTOR=$DESCRIPTOR"
      echo "TEST_ENV_REUSED=1"
      echo "BROWSER_PROVIDER=agent-browser"
      echo "BROWSER_INSTALLED=1"
      exit 0
    fi
  fi
  sh .ai/scripts/test-env-down.sh >/dev/null 2>&1 || true
fi

project_root=$(pwd)
if [ "$HAS_LAUNCHCTL" -eq 1 ]; then
  for stale_label in $(launchctl list | awk '$3 ~ /^devmentor-qa-/ { print $3 }'); do
    stale_job=$(launchctl print "gui/$(id -u)/$stale_label" 2>/dev/null || true)
    printf '%s' "$stale_job" | grep -Fq -- "$project_root" || continue
    stale_pid=$(printf '%s\n' "$stale_job" | sed -n 's/^[[:space:]]*pid = \([0-9][0-9]*\)$/\1/p' | head -n 1)
    stale_pgid=$([ -z "$stale_pid" ] || ps -o pgid= -p "$stale_pid" 2>/dev/null | tr -d ' ' || true)
    launchctl remove "$stale_label" >/dev/null 2>&1 || true
    case "$stale_pgid" in
      ''|*[!0-9]*|0|1) ;;
      *) kill -TERM -"$stale_pgid" >/dev/null 2>&1 || true ;;
    esac
  done
fi

free_port() {
  node -e 'const s=require("net").createServer();s.listen(0,"127.0.0.1",()=>{console.log(s.address().port);s.close()})'
}
fp_file() { stat -f '%z:%m' "$1" 2>/dev/null || stat -c '%s:%Y' "$1" 2>/dev/null; }
fingerprint() {
  {
    for path in $BUILD_INPUTS; do
      if [ -d "$path" ]; then
        find "$path" -type f ! -path '*/node_modules/*' ! -path '*/.next/*' ! -path '*/coverage/*' ! -path '*/storybook-static/*'
      elif [ -f "$path" ]; then
        echo "$path"
      fi
    done | LC_ALL=C sort | while IFS= read -r file; do printf '%s:%s\n' "$file" "$(fp_file "$file")"; done
    printf 'env:NODE_ENV=development\n'
  } | cksum | awk '{print $1"-"$2}'
}
build_needed() {
  [ "$FORCE_REBUILD" -eq 1 ] && return 0
  [ -f "$BUILD_CACHE" ] || return 0
  cached_fp=$(jq -r '.sourceFingerprint // ""' "$BUILD_CACHE" 2>/dev/null || echo '')
  cached_root=$(jq -r '.projectRoot // ""' "$BUILD_CACHE" 2>/dev/null || echo '')
  [ "$cached_fp" = "$(fingerprint)" ] || return 0
  [ "$cached_root" = "$(pwd)" ] || return 0
  for artifact in $ARTIFACTS; do [ -d "$artifact" ] || [ -s "$artifact" ] || return 0; done
  return 1
}

run_id="$(date -u +%Y%m%d-%H%M%S)-$$"
db_port=$(free_port)
app_port=$(free_port)
container="devmentor-qa-$run_id"
launch_label="devmentor-qa-$run_id"
database_url="postgres://devmentor:devmentor@127.0.0.1:$db_port/devmentor_qa"
base_url="http://127.0.0.1:$app_port"
session_secret=$(openssl rand -hex 32)
cat > "$ENV_FILE" <<EOF
DATABASE_URL=$database_url
SESSION_SECRET=$session_secret
APP_URL=$base_url
NODE_ENV=development
NEXT_TELEMETRY_DISABLED=1
DB_POOL_MIN=0
DB_POOL_MAX=5
DB_MIGRATIONS_SNAPSHOT=false
AUTH_IDENTITY_ADAPTER=mock
MAILER_ADAPTER=log
INTEGRATION_TEST_RUN=1
OPERATOR_EMAILS=mock-operator@devmentor.test
TEST_MENTOR_PASSWORD=not-used-mock-identity
EOF
chmod 600 "$ENV_FILE"
set -a
. "$ENV_FILE"
set +a

if [ "$HAS_DOCKER" -eq 1 ]; then
  docker run -d --rm --name "$container" \
    -e POSTGRES_DB=devmentor_qa -e POSTGRES_USER=devmentor -e POSTGRES_PASSWORD=devmentor \
    -p "127.0.0.1:$db_port:5432" postgres:17-alpine >/dev/null
  ready=0
  for _ in $(seq 1 60); do
    if docker exec "$container" pg_isready -U devmentor -d devmentor_qa >/dev/null 2>&1; then ready=1; break; fi
    sleep 1
  done
  [ "$ready" -eq 1 ] || { echo 'PostgreSQL did not become ready.' >&2; exit 1; }
else
  container=
  pg_data_dir="$project_root/$QA_DIR/pgdata-$run_id"
  rm -rf "$pg_data_dir"
  initdb -D "$pg_data_dir" -U devmentor -A trust -E UTF8 >/dev/null 2>&1
  pg_ctl -D "$pg_data_dir" -o "-p $db_port -h 127.0.0.1 -k $pg_data_dir" -l "$pg_data_dir.log" start >/dev/null
  ready=0
  for _ in $(seq 1 60); do
    if pg_isready -h 127.0.0.1 -p "$db_port" -U devmentor >/dev/null 2>&1; then ready=1; break; fi
    sleep 1
  done
  [ "$ready" -eq 1 ] || { echo 'PostgreSQL did not become ready.' >&2; exit 1; }
  createdb -h 127.0.0.1 -p "$db_port" -U devmentor devmentor_qa
fi

if build_needed; then
  npm ci --include=dev --prefer-offline
  npm run typecheck
  jq -n --arg at "$(date -u +%FT%TZ)" --arg fp "$(fingerprint)" --arg root "$(pwd)" \
    --arg artifacts "$ARTIFACTS" '{builtAt:$at,sourceFingerprint:$fp,projectRoot:$root,artifactPaths:$artifacts}' > "$BUILD_CACHE"
fi
npm run db:migrate
npm run db:seed

tool_path=$PATH
npm_command=$(command -v npm)
: > "$APP_LOG"
if [ "$HAS_LAUNCHCTL" -eq 1 ]; then
  launchctl submit -l "$launch_label" -- /bin/sh -c \
    'cd "$1"; set -a; . "$2"; set +a; PATH=$5; export PATH; exec "$6" run dev --workspace @devmentor/app -- --hostname 127.0.0.1 --port "$3" --webpack > "$4" 2>&1' \
    sh "$project_root" "$project_root/$ENV_FILE" "$app_port" "$project_root/$APP_LOG" "$tool_path" "$npm_command"
  sleep 1
  app_pid=$(launchctl print "gui/$(id -u)/$launch_label" | sed -n 's/^[[:space:]]*pid = \([0-9][0-9]*\)$/\1/p' | head -n 1)
  [ -n "$app_pid" ] || { echo 'launchd did not report an application pid.' >&2; exit 1; }
else
  launch_label=
  ( cd "$project_root"; set -a; . "$project_root/$ENV_FILE"; set +a
    exec "$npm_command" run dev --workspace @devmentor/app -- --hostname 127.0.0.1 --port "$app_port" --webpack
  ) > "$APP_LOG" 2>&1 < /dev/null &
  app_pid=$!
  disown "$app_pid" 2>/dev/null || true
fi
healthy=0
for _ in $(seq 1 120); do
  if [ "$HAS_LAUNCHCTL" -eq 1 ]; then
    launchctl print "gui/$(id -u)/$launch_label" >/dev/null 2>&1 || { tail -80 "$APP_LOG" >&2; exit 1; }
  else
    kill -0 "$app_pid" 2>/dev/null || { tail -80 "$APP_LOG" >&2; exit 1; }
  fi
  if curl -fsS --max-time 5 "$base_url/api/health" 2>/dev/null | jq -e '.status == "ok" and .database == "up"' >/dev/null 2>&1; then healthy=1; break; fi
  sleep 1
done
[ "$healthy" -eq 1 ] || { echo 'Application did not become ready.' >&2; exit 1; }

started_at=$(date -u +%FT%TZ)
browser_command="$(pwd)/node_modules/.bin/agent-browser"
platform=$(uname -s | tr '[:upper:]' '[:lower:]')
if [ "$HAS_LAUNCHCTL" -eq 1 ]; then
  keepalive_note="launchd keeps the app alive across command sessions."
else
  keepalive_note="a detached nohup background process keeps the app alive across command sessions (no launchd on this host)."
fi
if [ "$HAS_DOCKER" -eq 1 ]; then
  pg_note="Ephemeral PostgreSQL via Docker (postgres:17-alpine)."
else
  pg_note="Ephemeral PostgreSQL via a native initdb/pg_ctl cluster (no Docker daemon on this host)."
fi
jq -n \
  --arg runId "$run_id" --arg baseUrl "$base_url" --arg databaseUrl "$database_url" \
  --arg container "$container" --arg launchLabel "$launch_label" --arg pgDataDir "$pg_data_dir" --arg browserCommand "$browser_command" --arg startedAt "$started_at" \
  --arg platform "$platform" --arg notes "$pg_note migrations and idempotent seed applied. Webpack dev mode avoids the current Next.js Turbopack nested-worktree root bug. $keepalive_note Mock GitHub identity is enabled only for this disposable integration run." \
  --argjson appPort "$app_port" --argjson dbPort "$db_port" --argjson appPid "$app_pid" \
  '{version:1,runId:$runId,status:"running",mode:"dev",baseUrl:$baseUrl,startedByThisRepo:true,startScript:".ai/scripts/test-env-up.sh",stopScript:".ai/scripts/test-env-down.sh",app:{startCommand:"npm run dev --workspace @devmentor/app -- --webpack",port:$appPort,healthPath:"/api/health",pid:$appPid,launchLabel:$launchLabel},services:[{type:"postgres",host:"127.0.0.1",port:$dbPort,container:$container,pgDataDir:$pgDataDir,url:$databaseUrl,env:{DATABASE_URL:$databaseUrl}}],credentials:[{role:"mentor",username:"mock-mentor",passwordEnv:"TEST_MENTOR_PASSWORD"}],credentialsFile:".ai/qa/test-env.env",browser:{provider:"agent-browser",installed:true,command:$browserCommand,version:"0.36.0",descriptor:".ai/browsers/agent-browser.md",notes:"Repository-pinned agent-browser passed doctor."},testRunner:{name:"vitest+agent-browser",config:"vitest.integration.config.mts"},platform:$platform,startedAt:$startedAt,notes:$notes}' > "$DESCRIPTOR"

success=1
echo "TEST_ENV_STATUS=running"
echo "TEST_ENV_BASE_URL=$base_url"
echo "TEST_ENV_DESCRIPTOR=$DESCRIPTOR"
echo "TEST_ENV_REUSED=0"
echo "BROWSER_PROVIDER=agent-browser"
echo "BROWSER_INSTALLED=1"
