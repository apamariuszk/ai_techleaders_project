# What a session leaves behind: the written answer and the session note (E04-S02…S04)

Status: active, 2026-10-01. Epic [#10](https://github.com/open-mercato/ai_techleaders_project/issues/10);
stories [#27](https://github.com/open-mercato/ai_techleaders_project/issues/27) (E04-S02),
[#28](https://github.com/open-mercato/ai_techleaders_project/issues/28) (E04-S03),
[#29](https://github.com/open-mercato/ai_techleaders_project/issues/29) (E04-S04).

This is the spec all three stories record as owed (each was filed `--no-spec`, naming
`written-answer.md` / `session-notes.md`; #10 names `sessions-notes.md`, which is this file).
It does **not** cover the session itself — the 25/50-minute text exchange is
[`2026-09-14-text-session.md`](./2026-09-14-text-session.md) (E04-S01, #26), which deliberately
left the answer and the note to this document.

**It builds on two branches that are not on `master` yet**: `feat/epic-03-booking-and-payment`
(PR [#53](https://github.com/open-mercato/ai_techleaders_project/pull/53)) for `Booking`, and the
E04-S01 stack (PRs [#54](https://github.com/open-mercato/ai_techleaders_project/pull/54)–[#58](https://github.com/open-mercato/ai_techleaders_project/pull/58))
for `TextSessionService`, `/sessions/[bookingId]` and the session DTO. Every file path below is
read against that stack.

## 📝 TLDR

A mentee can today pay for a session and hold it as text, and the session then leaves nothing
behind: when the window closes the transcript is all there is. The proposal is the two artifacts
the brief says a 1.0 session produces — **one written answer** the mentor posts and the mentee
keeps, and **one session note** the mentor drafts and the mentee approves in full or declines
with a comment, kept privately by both and published nowhere. Both appear on the session screen
that already exists, behind the same party check; neither is reachable by anyone else, including
the operator.

## 📝 Problem Statement

- The working developer interviewed on 2026-08-20 got "two contradictory answers" elsewhere and
  shipped code they did not trust: "I don't want a course, I want an answer"
  `[INTERVIEW]` `research/2026-08-20-interview-working-dev.md`. What they are paying for is a
  written answer they can act on and come back to; a transcript of a 25-minute exchange is not
  that.
- The mentor interviewed on 2026-08-22 keeps a private notes file that rots, and "won't publish
  anything a mentee didn't agree to" `[INTERVIEW]` `research/2026-08-22-interview-mentor.md`. The
  note is the mentor's asset (D20); the mentee's approval is the gate (D02, R02).
- Nothing in the repository stores either artifact. `Booking` carries money and schedule;
  `session_messages` carries the exchange. There is no answer and no note, so D03's bar for the
  first iteration — a session that is *answerable* — is not met by E04-S01 alone.
- The design system already ships the panels for both (`WrittenAnswer`, `NoteReview`,
  `VersionHistory`, committed under E02's design handoff). They are rendered in Storybook and
  rendered nowhere in the product.

## 📝 Proposed Solution

Two artifacts, one screen, one party authority.

1. **The written answer is a field of the booking, not a record beside it.** Exactly one answer
   exists per session, it is posted by that session's mentor, and the mentee reads it in the
   session for as long as the booking exists. Two nullable columns on `bookings` carry it.
2. **The note is its own table with versions and a status.** `draft` → `awaiting_approval` →
   `approved` or `declined`; a decline carries a mandatory comment and the mentor's redraft is a
   **new version** rather than an edit of the refused one. There is no co-editing (R12) and no
   suggestion mode: the mentee approves or declines the exact text they were shown.
3. **Both hang off the party check that already exists.** `TextSessionService.party()` is the one
   place that decides who may read a private exchange; the answer reuses it directly and the new
   `SessionNoteService` resolves the booking through the same rule. An operator is refused the
   same way a stranger is.
4. **The operator sees counts, never text.** D20's co-editing signal is "notes declined more
   than once in a row", so the admin screen gets a per-session decline *count*. No route hands a
   note body to a non-party.

**Alternatives considered.**

- *A `WrittenAnswer` table.* Rejected: one row per booking, keyed by the booking, with no
  history asked for — a table whose only content is two of the booking's own fields. Adding
  history later is an additive table plus a backfill, and this spec does not pay for it now.
- *The note as a status column on `bookings`.* Rejected: the note has versions, and D20's decline
  count is the number of refused versions. A column cannot count what it overwrites.
- *Co-editing, or inline suggestions on the draft.* Rejected by R12/D20 as an active decision.
  The design makes the refusal legible instead: the mentee sees no edit control anywhere.
- *Emailing the answer body.* Rejected: an answer in an email leaves the product's access control
  for good, which is the opposite of R02's promise. The notification says an answer is there and
  links to it; the text stays behind the party check.
- *Folding both into `2026-09-14-text-session.md`.* Rejected: that spec is about a 25-minute
  window, and a note's state machine inside it would bury both. It says so itself.

## 📝 Research — what the leaders do, and what this skips

- **GitHub pull-request reviews** are exactly R12's shape: approve, or request changes with a
  comment, and the author pushes a new revision rather than the reviewer editing the text. The
  lesson taken: *keep the decline comment attached to the version it refused.* Without that, "which
  text did I approve?" is unanswerable six weeks later, which is precisely the question an approval
  gate exists to answer. Hence `version` + `declineComment` on the row, and the DS's
  `VersionHistory` showing them.
- **Stack Overflow / Discourse** separate the *accepted answer* from the thread that produced it.
  The lesson taken: the answer is a first-class artifact with its own place on the screen and its
  own state (owed / posted), not the last message in a transcript.
- **Intercom and Zendesk internal notes** are private by construction — a separate store, never
  joined into the customer-visible payload. The lesson taken: the note lives in its own table with
  **no list route at all**, and the public payload tests assert its absence rather than trusting a
  serializer to keep omitting it.
- **Google Docs suggestion mode** is the co-editing model R12 rules out; **DocuSign-style audit
  trails**, redline diffs between versions, threaded comments on a note and e-signature evidence
  are all complexity this skips. Two parties, one decision, one comment.
- **Mentoring marketplaces (Clarity.fm, Superpeer)** send a recap email after the call. Skipped
  deliberately, as above: notification yes, content no.

## 📝 Architecture

```mermaid
flowchart LR
    classDef newPart fill:#2f6feb,color:#fff,stroke:#1b4fb0
    classDef existingPart fill:#e5e7eb,color:#111,stroke:#9ca3af
    classDef plannedPart fill:#fef3c7,color:#111,stroke:#d97706

    screen["/sessions/[bookingId] (existing screen)"]:::existingPart
    answerPanel["answer-panel.tsx (new)"]:::newPart
    notePanel["note-panel.tsx (new)"]:::newPart
    answerRoute["PUT /api/sessions/{id}/answer (new)"]:::newPart
    noteRoutes["/api/notes/{id} + send approve decline (new)"]:::newPart
    textSession["TextSessionService (existing: party + window)"]:::existingPart
    noteService["SessionNoteService (new)"]:::newPart
    booking["bookings (existing: + 2 columns)"]:::existingPart
    notes["session_notes (new table)"]:::newPart
    bus["EventBus (existing)"]:::existingPart
    notif["NotificationService (existing)"]:::existingPart
    admin["/admin decline counts (new)"]:::newPart
    vault["vault publishing (later scope, D05)"]:::plannedPart

    screen --> answerPanel
    screen --> notePanel
    answerPanel --> answerRoute
    notePanel --> noteRoutes
    answerRoute --> textSession
    noteRoutes --> noteService
    noteService -->|party check| textSession
    textSession --> booking
    noteService --> notes
    textSession --> bus
    noteService --> bus
    bus --> notif
    noteService --> admin
    vault -.->|needs R02 approval, not built| notes
```

Takeaway: everything new routes through the existing party authority and the existing event
bus — the only genuinely new runtime component is `SessionNoteService` and its table. The vault
is drawn only to show what deliberately does **not** connect: nothing publishes a note in 1.0.

Reused without modification: `apiHandler` (envelope, CSRF on every mutation), the typed
`AppError`s, `assertOwnership`, `Clock` from the cradle, `useApiResource`, `apiCall`, `CrudForm`,
`WorkflowAction`, the `feedback/` components, and the DS panels `WrittenAnswer`, `NoteReview`,
`VersionHistory`, `SessionHeader`, `SessionTranscript`.

**Not** reused: `makeCrudRoute`. The note is a state machine whose verbs are domain transitions
(`send`, `approve`, `decline`) with a different authorized party per verb; a CRUD factory would
have to be told "PUT is mentor-only, POST /approve is mentee-only" per route anyway, and the
transitions would end up in the page. `apiHandler` + the service is the project's other sanctioned
shape and is the honest one here.

**Two new concept folders**, per the directory convention: `notes` (new) and additions to
`sessions`.

| File | What decides |
| --- | --- |
| `db/entities/bookings/booking.entity.ts` | the two answer columns and their bounds |
| `db/entities/notes/session-note-status.ts` | the status union, so the `CHECK` is generated from one list |
| `db/entities/notes/session-note.entity.ts` | the table, its versions, its partial uniques, its length bounds |
| `core/validators/sessions/answer-update.schema.ts` | the answer body's shape at the HTTP boundary |
| `core/validators/notes/note-draft.schema.ts` | the draft body's shape |
| `core/validators/notes/note-decline.schema.ts` | that a decline carries a comment |
| `core/services/sessions/text-session.service.ts` | who may post an answer, when, and what the session DTO reports about it |
| `core/services/notes/session-note.service.ts` | every note transition, who may make it, and what each party may read |
| `core/events/event-map.ts` | the four new event payloads |
| `core/services/notifications/notification.service.ts` | who is told, and with which notification kind |
| `app/api/sessions/[bookingId]/answer/route.ts` | nothing — schema in, service out |
| `app/api/notes/[bookingId]/{route,send,approve,decline}` | nothing — schema in, service out |
| `app/sessions/[bookingId]/answer-panel.tsx` | how the answer looks to each party |
| `app/sessions/[bookingId]/note-panel.tsx` | how the note looks to each party, and the decline form |
| `app/sessions/[bookingId]/session-screen.tsx` | the poll cadence once the window has closed |
| `app/admin/session-notes.tsx` | the operator's decline counts (numbers only) |

`sessionNoteService` is registered in `container.ts` and on the typed `Cradle` as a **scoped**
service, for the same forced reason as every other service holding `em` and the caller's own
`session`.

## 📝 Data Model

```mermaid
flowchart LR
    classDef newEntity fill:#2f6feb,color:#fff,stroke:#1b4fb0
    classDef changedEntity fill:#fef3c7,color:#111,stroke:#d97706
    classDef existingEntity fill:#e5e7eb,color:#111,stroke:#9ca3af

    entity_1["SessionNote (new)"]:::newEntity
    entity_2["Booking (+writtenAnswer, +writtenAnswerAt)"]:::changedEntity
    entity_3["SessionMessage (existing)"]:::existingEntity
    entity_4["User (existing)"]:::existingEntity
    entity_5["MentorProfile (existing)"]:::existingEntity
    entity_6["Notification (existing)"]:::existingEntity

    entity_1 -->|n-1 restrict| entity_2
    entity_3 -->|n-1 cascade| entity_2
    entity_2 -->|n-1 restrict| entity_4
    entity_2 -->|n-1 restrict| entity_5
    entity_6 -->|n-1| entity_2
```

Takeaway: the answer adds no entity at all, and the note attaches to the booking rather than to a
party — which is what makes "both keep it" a single row rather than two copies that can diverge.

### `bookings` — two additive nullable columns

| Column | Type | Why |
| --- | --- | --- |
| `written_answer` | `text` nullable | one answer per session; the booking already is the session's identity |
| `written_answer_at` | `timestamptz` nullable | when it was first posted; what `answerOwed` and the note's precondition read |

`MAX_ANSWER_LENGTH = 20000` lives in the `db` leaf next to the column, exactly like
`MAX_MESSAGE_LENGTH`, so the database `CHECK` and the zod validator cannot disagree and a body the
schema accepts can never come back as a 500 from Postgres. The check is spelled as two
comparisons rather than `between`, for the reason `session_messages_body_length` records (Postgres
rewrites `between` and MikroORM then reports permanent schema drift).

Replacing the answer **overwrites** `written_answer` and leaves `written_answer_at` at the first
posting: the mentee is told when the answer arrived, and there is no revision history in 1.0
(Q3).

### `session_notes` — the new table

| Column | Type | Notes |
| --- | --- | --- |
| `booking` | FK → `bookings`, `restrict` | see below |
| `version` | `integer` | 1, then 2 after each decline |
| `body` | `text` | 1…`MAX_NOTE_LENGTH` (20000), enforced by `CHECK` and by zod |
| `status` | enum `NOTE_STATUSES` | `draft` \| `awaiting_approval` \| `approved` \| `declined` |
| `decline_comment` | `text` nullable | 1…2000; non-null exactly when `declined` |
| `sent_at` | `timestamptz` nullable | non-null for every status except `draft` |
| `decided_at` | `timestamptz` nullable | non-null exactly for `approved` and `declined` |

Plus `baseProperties` (`id`, `createdAt`, `updatedAt`) like every other entity.

**`restrict`, not `cascade`, unlike `session_messages`.** A transcript is *about* a booking and
goes with it; the note is the mentor's asset, and destroying it as a side effect of a row delete
is the outcome D20 would least forgive. `Booking` itself restricts all three of its relations for
the same kind of reason (it is a money record); erasing a person who has a note is a
data-retention decision with its own rules, not a row delete.

**The database arbitrates the invariants**, following `bookings_active_slot_unique` rather than a
read-then-write:

| Constraint | What it guarantees |
| --- | --- |
| unique `(booking, version)` | version numbers do not collide under concurrent writes |
| partial unique `(booking) where status in ('draft','awaiting_approval')` | at most one live version per session — a mentor cannot have two drafts, and cannot redraft while one awaits a decision |
| partial unique `(booking) where status = 'approved'` | a session has at most one approved note, for ever |
| `CHECK` decline comment | `(status = 'declined') = (decline_comment is not null)` |
| `CHECK` sent | `status = 'draft' or sent_at is not null` |
| index `(booking, version desc)` | the only read this table has: this booking's versions, newest first |

A redraft is therefore `insert version = max + 1`, and two concurrent redrafts produce one row and
one `23505` — decided by PostgreSQL, not by a check the loser also passed a millisecond earlier.

**Sensitive data.** Both artifacts are free text written by one person about another person's
work. They are never logged (the rule is ids and outcomes; the logger's redaction is only a
backstop), never placed in a public payload, never emailed, and reachable only through the party
check. There is no encryption at rest beyond the database's own — the same treatment the session
transcript already gets, and a change to that is a project-wide decision rather than this spec's.

### Migrations

Two migrations, each with `up` **and** `down`: `written_answer` (two nullable columns, additive)
and `notes` (new table, additive). Nothing existing is tightened, so both are non-breaking under
`BACKWARD_COMPATIBILITY.md` §3.

## 📝 API Contracts

Every route is wrapped in `apiHandler`, so every non-`GET` requires the `x-devmentor-request`
CSRF header and is therefore called through `apiCall` / `CrudForm` and never a native form post.
All of them answer the `{ ok, data }` / `{ ok, error }` envelope; none of them redirects.

| Route | Verb | Who | Refused when |
| --- | --- | --- | --- |
| `/api/sessions/{bookingId}/answer` | `PUT` | the booking's mentor | not a party (403), booking not confirmed (404), window `not_started` (409), an approved note exists (409) |
| `/api/notes/{bookingId}` | `GET` | both parties | not a party (403), booking not confirmed (404) |
| `/api/notes/{bookingId}` | `PUT` | the booking's mentor | no written answer yet (409), a version awaits the mentee (409) |
| `/api/notes/{bookingId}/send` | `POST` | the booking's mentor | current version not `draft` (409) |
| `/api/notes/{bookingId}/approve` | `POST` | the booking's mentee | current version not `awaiting_approval` (409) |
| `/api/notes/{bookingId}/decline` | `POST` | the booking's mentee | current version not `awaiting_approval` (409), comment missing (422) |

`403` versus `404` follows the rule E04-S01 set and gives the same two messages: a booking that is
not confirmed does not exist, and a caller who is not one of its two parties is told plainly that
it belongs to someone else. A non-party is refused on every route above, **operators included** —
the only thing an operator may read is a count, and that is reached from `/admin`, not from here.

`409` and not `422` on every transition refusal: the body is valid, the state is wrong. The clock
and the row are both re-read inside the write, so a tab left open across a transition is told what
actually happened instead of overwriting it.

### Additive fields on the existing session view

`GET /api/sessions/{bookingId}` (E04-S01) gains, additively — §1 of
`BACKWARD_COMPATIBILITY.md` permits adding to a response:

```ts
answer: { body: string; postedAt: string } | null;
answerOwed: boolean;        // window ended and no answer yet
viewerRole: 'mentee' | 'mentor';
```

`viewerRole` is reported rather than inferred in the browser, for the same reason `viewerUserId`
already is: one screen serves both sides, and a client that guessed which side it was on would
eventually show a mentee an editor.

### The note view

`GET /api/notes/{bookingId}` answers one DTO for both parties, **scoped by who is asking**:

```ts
{
  current: NoteVersionDto | null;      // null when nothing has been written yet
  history: NoteVersionDto[];           // newest first
  declineCount: number;                // versions with status 'declined'
  canDraft: boolean;                   // mentor only
  viewerRole: 'mentee' | 'mentor';
}
```

**A `draft` the mentor has not sent is invisible to the mentee** — it is excluded from both
`current` and `history` for that caller, so the mentee sees "nothing awaits you" rather than a
403. R12 gives the mentee a decision on a *sent* note; an unsent draft is the mentor working.

## 📝 UI/UX

Both panels live on the session screen that already exists, below the transcript, so there is one
address per session and one party check behind it. Both are colocated with that page
(`answer-panel.tsx`, `note-panel.tsx`) because each has exactly one consumer; both compose DS
components and draw no boxes of their own.

Prototype: `.ai/specs/assets/sessions-notes/` — four self-contained HTML mockups, opened directly
in a browser (no build step). They reuse the design system's own tokens and `.dm-product-*` rules
so the layout is faithful, and they are illustrations of flow and state, never working software:

| File | What it shows |
| --- | --- |
| `mockup-01-mentee-answer-owed.html` | the mentee after the window closed, answer still owed |
| `mockup-02-mentor-draft-note.html` | the mentor with the answer posted and a draft ready to send |
| `mockup-03-mentee-approve-or-decline.html` | the mentee's decision, with the comment required and no edit control |
| `mockup-04-note-approved-private.html` | the settled approved note and the decline in its version history |

**The written answer** uses `WrittenAnswer` (`state: 'owed' | 'posted'`):

| Viewer | Window open | Window ended, no answer | Answer posted |
| --- | --- | --- | --- |
| mentee | panel absent | "Awaiting answer", with the panel's own copy and no deadline promised (R14) | the answer, with when it arrived |
| mentor | editor, optional | editor, with "Your written answer is still owed" | the answer, with "Replace the answer" until a note is approved |

The mentor's editor is a `CrudForm` bound to `answer-update.schema.ts` with `method: 'PUT'` — not
a hand-rolled form, and not a native one (it could not set the CSRF header).

**The note** uses `NoteReview` + `VersionHistory`, whose copy already carries the privacy line
("This note is private. Approving it does not publish it."):

| Viewer | No answer yet | Draft unsent | Awaiting approval | Declined | Approved |
| --- | --- | --- | --- | --- | --- |
| mentee | panel absent | "nothing awaits you" | the text, **Approve** and **Decline with a comment**, no edit control anywhere | the mentor's turn, with the mentee's own comment quoted | the approved note, marked private |
| mentor | "The written answer comes first." | the draft editor and **Send for approval** | read-only until the mentee decides | the mentee's comment and **Redraft** (a new version) | the approved note, marked private |

Decisions that are not standard CRUD:

- **Approve is a `WorkflowAction`** (POST, no body) — one irreversible press, so it carries a
  confirmation step and the button says what it does rather than "OK".
- **Decline is a `CrudForm`** bound to `note-decline.schema.ts`, so the mandatory comment arrives
  with `fieldErrors.comment` on the control that needs it rather than as a banner. Footer actions
  align right with Cancel before the primary action, per the project's confirmed design rules.
- **No edit control is rendered for the mentee, in any state.** The absence is the feature (R12),
  and an integration assertion proves the mentee's accessibility snapshot carries no textbox for
  the note body.
- Facts in the panels are separated by spacing and chips, never by dots or middle dots.
- `aria-live` on each panel's status, because both change under a poll rather than under a click.

**The poll cadence has to change, and this is a real consequence of E04-S01.** `session-screen.tsx`
today stops polling the moment the window reports `ended` — which is exactly when the answer and
the note start arriving. `pollMs` is already in `useApiResource`'s effect dependencies, so the fix
needs no hook change: the screen passes `SESSION_POLL_MS` (5 s) while the window is open and
`SETTLING_POLL_MS` (30 s) once it has ended *and* something is still outstanding for this viewer
(the answer is owed, or a note awaits their decision), and stops when nothing is. The slower
cadence is honest about what it is waiting for: a human writing prose, not a message being typed.
Nobody has to sit on the page either way — the notification and its email are what actually tell
a party.

The note panel is its own `useApiResource` on `/api/notes/{bookingId}` with the same rule, so a
settled note costs no requests.

## 📝 Events and notifications

Four additive entries in `event-map.ts`, each emitted **after** its transaction commits, and four
new `NOTIFICATION_KINDS` (append-only, per the union's own note):

| Event | Payload | Who is told | Kind |
| --- | --- | --- | --- |
| `sessions.answer.posted` | `{ bookingId, mentorProfileId, menteeId, postedAt }` | the mentee | `answer_posted` |
| `notes.note.sent` | `{ bookingId, noteId, version }` | the mentee | `note_awaiting_approval` |
| `notes.note.approved` | `{ bookingId, noteId, version }` | the mentor | `note_approved` |
| `notes.note.declined` | `{ bookingId, noteId, version, declineCount }` | the mentor | `note_declined` |

The subscriber is E03-S04's `NotificationService`, unchanged in shape: an in-product row plus its
existing best-effort email. **No notification body ever contains the answer or the note text** —
it says an artifact is waiting and links to the session. A failed email leaves the in-product row,
which is the record, exactly as `onBookingConfirmed` already behaves.

`declineCount` travels on the decline event because D20's revisit trigger is "more than once in a
row": the count is the signal, and a subscriber that had to go and count would be a subscriber
that can disagree with the table.

## 📝 Edge Cases & Failure Scenarios

1. **The window closes and no answer comes.** The mentee sees "Awaiting answer" and no date, for
   ever if need be (R14 promises nothing about speed). The mentor sees it as owed. Nothing expires.
2. **The mentor answers while the session is still open.** Allowed: the answer is the deliverable,
   not a post-session ceremony. The composer stays open until `endsAt` as before.
3. **The mentor replaces a posted answer.** Allowed until an approved note exists; after that the
   route answers 409, because a note the mentee approved against one answer must not come to
   describe a different one (Q3). `written_answer_at` keeps the first posting.
4. **A note is drafted before the answer exists.** 409 "The written answer comes first." (D05
   orders them, and the note is written *about* the answer.)
5. **The mentee opens the note panel while the mentor's draft is unsent.** They see that nothing
   awaits them — not a 403, and not an empty editor.
6. **A decline arrives with no comment.** 422 with `fieldErrors.comment`; the form shows it on the
   field. R12 is the reason, and it is the one validation this feature cannot soften.
7. **The mentee approves while the mentor is sending a redraft.** Both transitions re-read the row
   inside the write and the partial unique index allows exactly one live version, so one succeeds
   and the other gets 409 with what actually happened. Neither can produce two live versions or a
   second approved one.
8. **A third user or an operator opens any note route.** 403 with the session's own wording. No
   body, no version count, no existence hint beyond "this belongs to its two parties".
9. **The booking is not confirmed, or is cancelled.** 404 on every route here, through the same
   `party()` as E04-S01. The states cannot overlap in practice: cancellation is only possible more
   than 24 hours before the start (D10/R09) and neither artifact can exist before the window opens.
10. **The mentee's or mentor's user row is deleted.** Already refused by `Booking`'s `restrict`;
    the note's own `restrict` on the booking means a note is never destroyed as a side effect.
11. **A 20000-character body, or an empty one.** Refused by zod at the boundary with a field
    error, and by the `CHECK` if that is ever bypassed. The two bounds come from one constant.
12. **The notification email fails.** Logged and swallowed, as E03-S04 already does; the
    in-product notification and the panel are the record.
13. **An approval cannot be taken back.** `status = 'approved'` is terminal and the partial unique
    index allows exactly one approved note per session, so a mis-click is not undoable in the
    product — which is why Approve is confirmed rather than a bare button, and why the panel says
    what approval does before it is pressed. The remedy in 1.0 is an operator acting by hand and
    logging it (R18); an un-approve transition would need its own recorded decision, since it
    reopens a gate D02 closed.
14. **Manual QA cannot reach any of these states through the product**, because a booking must
    start at least two hours ahead. `QaSessionSeeder` is extended with an ended session that has
    an answer, one with an answer and a note awaiting approval, and one with a declined version —
    run explicitly through `npm run db:seed:sessions`, never from the default seed.

## 📝 Risks & Impact Review

- **This spec sits on two unmerged branches.** `Booking` and `TextSessionService` both live only
  on PRs #53 and #54–#58. If E03's `Booking` shape or E04-S01's DTO changes, the two columns and
  the three additive DTO fields change with them. No existing file is rewritten by this spec; the
  conflict surface is `booking.entity.ts`, `text-session.service.ts`, `session-screen.tsx` and
  `event-map.ts`, all additively.
- **Two columns are added to `bookings`, a money table.** Additive and nullable, so §3's
  non-breaking test is met, but it is a migration on the table payouts read; `SDLC.md` puts
  schema migrations at the higher-risk end and the implementation PR should carry `risk-medium`
  with the migration's `down` exercised.
- **No revision history for the answer** and no export for either artifact (D05 keeps the vault
  later; #29 puts export out of scope). "Both keep it privately" is delivered as "both can read it
  in the product for as long as the booking exists" — a mentor who wants it in their own notes
  file copies it. If that reading is wrong, the fix is additive (an export route), not a redesign.
- **The note is reachable only through its booking's session screen.** There is deliberately no
  list route (the privacy guarantee depends on it), which also means a mentor cannot yet browse
  their own notes. That is the asset the vault would eventually index; naming it here is the
  honest statement of what 1.0 does not do.
- **The operator exception is counts-only** and it is a scoping exception either way. E05-S03's
  dispute resolution will need more than a count, and it needs its own recorded decision about
  disclosure — not a role check quietly added to these routes.
- **Freezing the answer once a note is approved** is a product call, not a rule anyone wrote
  (Q3). It is reversible by deleting one guard.
- **Approval is the one state change with no undo path** (edge case 13). Every other transition
  is reachable from the next one — a decline reopens drafting, an answer can be replaced — but
  an approved note is terminal, by the same reading of D02 that makes the approval worth having.
  The cost is borne by the mentee, who is the party the gate protects, so the mitigation is the
  confirmation step and the panel's own copy rather than a reversal route.
- `BACKWARD_COMPATIBILITY.md`: §1 (six new routes, three additive response fields), §3 (two
  additive columns, one new table), §6 (four new events), §7 (CSRF on every mutation, inherited),
  §8 (R02, R12, D02, D05, D20 are the decisions this implements; none is contradicted and none is
  superseded).

## 📝 Decisions in play

| Id | What it says | Owner | How this spec stands to it |
| --- | --- | --- | --- |
| D02 / R02 | nothing from a session is published without the mentee's approval | both founders | implements it; nothing publishes at all in 1.0 |
| D20 / R12 | the mentor drafts, the mentee approves in full or declines with a comment, the mentor redrafts, no co-editing | founder A | implements it, including the decline count as the revisit signal |
| D05 | 1.0 delivers the written answer and a privately kept note; the vault is later | founder A | implements the first half and builds nothing toward the second |
| D03 | the first iteration must leave an "answerable" session | founder A | Phase 1 alone clears this bar |
| R03 / N01 | sessions are text, and every session screen says so | founder A | unchanged — the notice stays where E04-S01 put it |
| R14 | no promise about how soon an answer arrives | founder A | the owed state names no date |
| R01 / D01 | 25 or 50 minutes | founder A | unchanged; only the window's *end* matters here |

## Resolved assumptions (autonomous defaults)

This spec was written by an unattended run. Every question below was resolved by the run, not by a
human; each is stated so it can be overridden before the implementation starts.

| # | Question | Applied default | Why | Reversibility |
| --- | --- | --- | --- | --- |
| Q1 | One spec for the answer and the note, or one each? | **One spec, three independently shippable phases.** | #28 and #29 ask for a shared spec and #27 offers to fold in; all three share one party check, one visibility rule and one screen, and splitting would duplicate the design that matters. Each phase still ships on its own PR. | Reversible — a phase can be lifted into its own spec without changing a design decision. |
| Q2 | Is the note in the first iteration (D13), given the brief's "Later" list naming `E04-S04`? | **Yes — all three phases are 1.0; Phase 1 is the first-iteration commitment.** | The brief's 1.0 statement twice includes the mentee-approved note (lines 45, 79) and D13's own list is from a backlog that "is not in this repository", so its `E04-S04` is not this repo's #29. Phasing protects the schedule either way: D03's "answerable" bar is cleared by Phase 1 alone. | Reversible — if founder A says the note is later scope, Phases 2 and 3 move out and nothing in Phase 1 changes. |
| Q3 | May the written answer be revised after it is posted? | **Yes, by its mentor, until a note is approved; then it is frozen.** No revision history. | #27 reads the plain answer as "one answer, replaceable"; freezing at approval keeps R02 meaningful (an approval must refer to a fixed answer). No history is the smaller surface and is additive later. | Reversible — the freeze is one guard; history is a new table. |
| Q4 | May the mentor keep editing a draft after sending it for approval? | **No.** Sent is read-only for both until the mentee decides; a decline opens a new version. | R12 asks the mentee to approve *in full*, which requires a text that cannot move under them. It is also the smaller surface: no edit-after-send path and no "has this changed since you read it" problem. | Reversible — an edit-while-awaiting path is additive. |
| Q5 | How much of a session may the operator read for D20's decline count? | **Counts only. No route exposes a note body or an answer to a non-party.** | E04-S01 already refuses the operator the transcript; D20 needs a number, not text. The privacy-preserving option is also the one that needs no new disclosure decision. | Reversible — E05-S03 can widen it, with its own recorded decision. |

None of these required human confirmation before the design could be written: each is reversible
and none weakens data scoping, a compatibility surface, or an active product decision.

## 📋 Phasing

- **Phase 1 — the written answer (#27).** One answer per session, posted by its mentor, read by
  its mentee, with an explicit owed state. Ships alone and clears D03's bar.
- **Phase 2 — the draft note, sent for approval (#28).** The mentor drafts and sends; the mentee
  sees it awaiting their approval and has no edit control. Ships on top of Phase 1.
- **Phase 3 — approve, decline, redraft, and the decline count (#29).** The mentee decides; the
  mentor redrafts as a new version; both keep the approved note privately; the operator reads the
  count.

Each phase leaves the product working and each is its own PR referencing this spec as
`Source doc:`. Every step below adds its new or changed production files to `coverage.include` in
`vitest.config.mts` in the same change, and ends with `npm run test:unit:coverage` at 100% per file
on statements, branches, functions and lines.

## 📋 Implementation Plan

### Phase 1 — the written answer (#27)

1. **1.1** Add `MAX_ANSWER_LENGTH`, `writtenAnswer` and `writtenAnswerAt` to
   `booking.entity.ts` with the two-comparison length `CHECK`; generate migration
   `written_answer` with `up` and `down`; entity and migration tests.
2. **1.2** `core/validators/sessions/answer-update.schema.ts` — `body` trimmed, 1…`MAX_ANSWER_LENGTH`,
   with the field message the panel shows.
3. **1.3** `TextSessionService`: `postAnswer(bookingId, input)` (mentor of this booking only, via
   `assertOwnership` against `mentorProfile.user.id`; refused while `not_started`);
   `getForParty` additionally returns `answer`, `answerOwed` and `viewerRole`. The
   approved-note freeze is **not** implemented here — no note can exist yet — and arrives with
   Phase 3, which is where its only trigger comes from.
4. **1.4** `app/api/sessions/[bookingId]/answer/route.ts` — `PUT` through `apiHandler`.
5. **1.5** `sessions.answer.posted` in `event-map.ts`, `answer_posted` in `NOTIFICATION_KINDS`
   (+ migration for the enum `CHECK`), and the `NotificationService.onAnswerPosted` subscriber
   telling the mentee.
6. **1.6** `answer-panel.tsx` composed from `WrittenAnswer` + `CrudForm`; wire it into
   `session-screen.tsx` and change the poll cadence to `SETTLING_POLL_MS` while something is
   outstanding after the window ends.
7. **1.7** Extend `QaSessionSeeder` with an ended session carrying an answer and an ended session
   still owing one.
8. **1.8** Integration scenario: the mentor posts, the mentee reads it in the browser, a second
   mentor is refused, and `GET /api/mentors` + `GET /api/mentors/[slug]` carry no answer field.

### Phase 2 — the draft note sent for approval (#28)

9. **2.1** `db/entities/notes/session-note-status.ts` and `session-note.entity.ts` with both
   partial uniques and all three `CHECK`s; migration `notes` with `up` and `down`; entity and
   migration tests.
10. **2.2** `core/validators/notes/note-draft.schema.ts`.
11. **2.3** `core/services/notes/session-note.service.ts` — `getForParty` (party check through the
    text-session authority; the mentee never sees an unsent draft), `saveDraft` (mentor only;
    requires `writtenAnswerAt`; refused while a version awaits the mentee), `sendForApproval`
    (`draft` → `awaiting_approval`, stamps `sentAt`); register in `container.ts` and `cradle.ts`.
12. **2.4** `app/api/notes/[bookingId]/route.ts` (`GET`, `PUT`) and
    `app/api/notes/[bookingId]/send/route.ts` (`POST`).
13. **2.5** `notes.note.sent` + `note_awaiting_approval` and the subscriber telling the mentee.
14. **2.6** `note-panel.tsx` composed from `NoteReview` + `VersionHistory` + `CrudForm`, with the
    mentor's draft editor and Send, and the mentee's read-only awaiting view; its own polled
    resource.
15. **2.7** Integration scenario: the mentee's accessibility snapshot of a sent note has **no**
    textbox for the body, and a third user is refused the note route.

### Phase 3 — approve, decline, redraft, and the count (#29)

16. **3.1** `core/validators/notes/note-decline.schema.ts` — `comment` 1…2000, required.
17. **3.2** `SessionNoteService`: `approve` (mentee only; `awaiting_approval` → `approved`,
    `decidedAt`), `decline` (mentee only; → `declined` with the comment), the redraft path
    (`saveDraft` after a decline inserts `version + 1`), and `declineCount`; turn on Phase 1's
    answer-freeze guard now that an approved note can exist.
18. **3.3** `app/api/notes/[bookingId]/approve/route.ts` and `.../decline/route.ts`.
19. **3.4** `notes.note.approved` and `notes.note.declined` + their two notification kinds and
    subscribers telling the mentor.
20. **3.5** `note-panel.tsx`: the mentee's Approve (`WorkflowAction`, confirmed) and Decline
    (`CrudForm`), the mentor's quoted comment and Redraft, and the approved-and-private state for
    both.
21. **3.6** `app/admin/session-notes.tsx` plus its nav entry — per-session decline counts,
    numbers only, operator-guarded, with both the authorized and the redirected branch tested.
22. **3.7** Integration scenario: decline without a comment is refused on the field; two declines
    show as a count of 2 to the operator and as no text anywhere else; an approved note appears in
    no public payload and no list route.

## 📝 Acceptance criteria

Phase 1 (#27):

1. **Given** a held session, **when** its mentor posts the written answer, **then** the mentee
   sees it in the session and is notified that it is there. (D05)
2. **Given** a session whose window has ended with no answer, **when** the mentee opens it,
   **then** it says the answer is still owed and names no date. (D03, R14; negative)
3. **Given** a posted answer, **when** the mentee opens the session weeks later, **then** the
   answer is still there. (D05)
4. **Given** the mentor of a *different* session, **when** they try to post an answer to this one,
   **then** they are refused. (data scoping; negative)

Phase 2 (#28):

5. **Given** a session with a written answer, **when** the mentor writes a draft note and sends it
   for approval, **then** the mentee sees it marked as awaiting their approval. (R12)
6. **Given** a draft note that has not been sent, **when** the mentee looks, **then** nothing
   awaits them and the draft is nowhere. (R12)
7. **Given** a sent note, **when** the mentee looks for a way to edit it, **then** there is none:
   only approve, or decline with a comment. (R12; negative)
8. **Given** a session with no written answer, **when** the mentor tries to draft a note, **then**
   it is refused. (D05; negative)

Phase 3 (#29):

9. **Given** a sent note, **when** the mentee approves it, **then** it becomes an approved note
   visible to both parties and marked private. (D05, R02)
10. **Given** a sent note, **when** the mentee declines it with a comment, **then** the mentor sees
    the comment and can redraft as a new version, and the declined version never reads as
    approved. (R12)
11. **Given** a decline with no comment, **when** it is submitted, **then** it is refused on the
    comment field. (R12; negative)
12. **Given** an approved note, **when** any other user, the mentor list, any public page or any
    list route is checked, **then** the note appears nowhere. (R02, D05; negative)
13. **Given** a session whose note was declined twice, **when** the operator reads the session,
    **then** the number of declines is visible and no note text is. (D20, R02)
14. Unit coverage is 100% (statements, branches, functions, lines) on every production file each
    phase adds or changes, each listed in `coverage.include`; the integration scenarios above run
    against a real database and a real browser.
