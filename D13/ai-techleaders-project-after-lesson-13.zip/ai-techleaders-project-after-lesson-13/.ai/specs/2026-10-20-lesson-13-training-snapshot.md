# Stan szkoleniowy do lekcji 14

## Problem i cel

Snapshot po lekcji 13 musi zawierać Epik 04 oraz trzy celowe błędy pokazane w nagraniu lekcji 14. Sam commit 6c86c10 zawiera poprawną obsługę tych przypadków, więc nie wystarcza do ćwiczenia.

## Poza zakresem

Nie zmieniamy głównej gałęzi aplikacji ani jej wdrożeń. Jest to wyłącznie wariant szkoleniowy do archiwów kursu.

## Podejście

Na bazie 6c86c10 odtwarzamy zmiany scenariusza z istniejącego commita nagraniowego 948b8bd: brak opisu mentora renderuje undefined, podsumowanie 50 minut pokazuje cenę 25 minut, a dwa serwisy traktują warszawski czas lokalny jako UTC. Zachowujemy zakres testów z tamtego nagrania, który celowo nie obejmuje tych przypadków brzegowych. Nie jest to deklaracja poprawności produktu.

Dodajemy jawne dane szkoleniowe i polecenie npm run db:seed:lesson-14, uruchamiane po podstawowym seedzie wyłącznie w osobnej bazie szkoleniowej. Dane obejmują cenę 90/180 PLN i slot około 30 minut od chwili uruchomienia seeda. Zmiany nie trafiają do zwykłego seeda.

## Kryteria odbioru

- Przeglądarka pokazuje undefined na /m/ada-legacy.
- Wybór 50 minut na /m/mock-mentor pokazuje 90 PLN w podsumowaniu mimo oferty 180 PLN.
- Slot około 30 minut w przyszłości można wybrać i zarezerwować, mimo reguły dwóch godzin.
- Zrzuty ekranu pochodzą z działającej aplikacji i leżą w Downloads uczestnika zadania.
- Archiwa ZIP i TGZ zawierają identyczny, zweryfikowany kod z Epikiem 04.
