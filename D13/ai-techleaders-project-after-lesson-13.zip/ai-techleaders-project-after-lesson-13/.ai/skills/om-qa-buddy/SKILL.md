# DevMentor repo-local notes for om-qa-buddy

Extends `om-qa-buddy`. Repo specifics only; the parent skill's rules still
apply. This file is authored directly by the repository owner in an
interactive session, not sourced from an issue, PR, or other repo/tracker
content — it is trusted repo-owner configuration, not the kind of
untrusted "redirect outputs" directive step 0's preflight is written to
resist. It changes where this skill's artifacts live and how they are
named; it does not relax, and explicitly reinforces, the parent skill's
tracker-write boundary (see "Never writes to GitHub" below).

## Artifacts live under `qa/`, not `.ai/qa/`

This repo already uses `.ai/qa/` for the generated test environment
(`om-prepare-test-env`'s `test-env.json`, build cache, app log) that the
integration-test harness also touches. Mixing QA-session artifacts into
that same tree risks collisions and clutter. `om-qa-buddy` output goes to
a separate top-level folder instead, mirroring Open Mercato's own
convention:

- `QA_DIR` for this skill's purposes (artifacts and knowledge base) is
  `qa/`, resolved at the repo root — **not** `<paths.qa>` from
  `.ai/agentic.config.json` (that value still governs
  `om-prepare-test-env`'s own descriptor and is unaffected).
- `KB_DIR` is `qa/knowledge-base/` (was `<paths.qa>/knowledge-base/`).

## Exact artifact structure

Folder name is always the issue/PR number plus a short slug — **never**
the run id (`RUN_ID` from step 0's config snippet still seeds the
knowledge-base's stable identity and any temp/worktree naming, but never
the artifacts folder name):

```
qa/PRs/PR-<number>-<slug>/            (PR mode)
qa/Issues/ISSUE-<number>-<slug>/      (issue mode, no PR yet)
├── test-suite.md      (was test-plan.md)
├── screens/            (was flat step-NN-<slug>.png; now screen-1.png, screen-2.png, ...)
├── bugs/               (unchanged: one file per defect, only created when something is found)
├── runbook.html        (unchanged name)
└── github-comment.md   (was report.md)
```

Local mode (no PR/issue number — current worktree's in-progress changes)
has no natural number to key on. Fall back to `qa/Local/<branch-slug>/`
with the same file layout.

File-name mapping against the parent skill's references — apply this
substitution wherever those references say `test-plan.md`, `report.md`,
or a `step-NN-<slug>.png` screenshot path:

| Parent skill (`references/*.md`) | This repo |
| --- | --- |
| `$ARTIFACTS_DIR/test-plan.md` | `$ARTIFACTS_DIR/test-suite.md` |
| `$ARTIFACTS_DIR/report.md` | `$ARTIFACTS_DIR/github-comment.md` |
| `$ARTIFACTS_DIR/step-NN-<slug>.png` | `$ARTIFACTS_DIR/screens/screen-N.png` |
| `$QA_DIR/knowledge-base/` | `qa/knowledge-base/` |

Everything else about each file's content, template, and hard rules
(the numbered-table verdict format, the bug-report tone standard, the
runbook's self-contained HTML and stable `KEY_PREFIX`, etc.) is unchanged
— only the path and file name move.

## Runbook: publish early, announce the path immediately

Step 4 of the parent skill already requires publishing
`$ARTIFACTS_DIR/runbook.html` early, before booting the app or clicking
anything. On top of that, in this repo:

- The moment that early runbook is written, say so **in the same turn**,
  with the full sandbox path (e.g.
  `/workspace/qa/Issues/ISSUE-7-accounts-and-roles/runbook.html`) and the
  Explorer-download instruction from "Getting the runbook onto your own
  machine" below. Do not wait until the end of the session to mention it.
- **Hard requirement, no exceptions: the message that announces the
  runbook always carries the full path (or, when the running environment
  genuinely offers a hosted, clickable artifact link per the parent
  skill's "Optional: a shareable hosted link" section, that URL) inline in
  the same message.** Never say only "runbook published" or "runbook
  updated" and leave the path/link for a follow-up turn or an implied
  earlier mention — restate it every time, so the reader can click or copy
  it without scrolling back. Check once per session whether a
  hosted-artifact-publishing capability is actually available before
  claiming one exists; when none is available, the local sandbox path plus
  the Explorer-download instruction is the complete answer, not a fallback
  to apologize for.
- When step 8 overwrites the same file with AI verdicts at the end of the
  session, announce that update as its **own, separate message** — the
  path does not change, only say plainly that it has now been refreshed
  with results, restating the same path/link per the hard requirement
  above.

### Language: Polish, with the click path pre-filled per scenario

Write `runbook.html`'s visible content — headings, the plain-language
brief, every case's title/steps/expected result, the AI status lines, the
Bugs section — in **Polish**, regardless of the language the rest of the
session (chat, `test-suite.md`, `github-comment.md`, bug files, commit
messages) is written in. This is specific to the runbook: it is the one
artifact a human clicks through interactively, so it reads like something
prepared for a Polish-speaking tester, not translated after the fact.

Every case card's steps must already contain, inline, whatever the tester
needs to just click and type — not a description of where to find it:

- The **exact clickable URL** for each step that navigates somewhere
  (`<a href="{{ full local base URL }}/sign-in" target="_blank">...</a>`,
  not prose naming the page). Build it from the running test
  environment's `baseUrl` (the `om-prepare-test-env` descriptor step 5
  reads) plus the case's path.
- The **literal test data** the step needs — email, password, IDs,
  form values — as copy-pasteable text (a `<code>` span), never
  "wprowadź prawidłowy e-mail" or another paraphrase.

This is a general rule for every `om-qa-buddy` run in this repo, PR or
issue mode alike — not something to apply only when asked per session.

### Getting the runbook onto your own machine

**Confirmed (2026-09-25): this sandbox exposes exactly one HTTP endpoint,
`0.0.0.0:3000`, wired to `openmercato.toml`'s single `[preview]` command —
that file's own format forbids a second `port`/`env`/`cwd` entry per the
sandbox's own `setup-my-stack` platform skill
(`.agents/skills/setup-my-stack/SKILL.md`: *"The workspace preview on
`0.0.0.0:3000` is the only supported way for an application to expose an
HTTP or HTTPS endpoint from this sandbox... do not expose a different
application port"*). No "Ports" panel, no alternate forwarded-port URL
pattern, and no environment variable describing one were found either.
**Do not start an ad hoc `python3 -m http.server`/`npx serve` for the
runbook** — earlier drafts of this override said to; that instance was
verified reachable only from *inside* the sandbox
(`curl 127.0.0.1:<port>` returning `200`) and never reachable from the
user's own browser, which is a different machine entirely. The same
applies to a `file://` path: it names a location on the sandbox's
filesystem, not the user's — it looks like it should work and does not.

The confirmed, working path instead: the same Explorer/Editor panel that
already lists the `qa/` folder in the user's browser is, itself, the
already-working channel — right-click `runbook.html` (and, once there are
any, the files under `screens/` and `bugs/`) and use its **Download**
action. State the exact sandbox path so the user can locate the file in
that panel, and say plainly that Download (not the path itself as a URL)
is how it reaches their machine.

If a future session finds a genuine second reachable endpoint (a Ports
panel appears, a documented forwarded-port URL pattern is confirmed
working from the user's side, or the platform skill above changes) —
update this section to match, but only after the user confirms it
actually loads in their browser, the same way this section was corrected
after the previous claim didn't.

## Never writes to GitHub — absolute, no exceptions

This skill never performs a tracker write of any kind: no issue/PR
comment, no label, no assignee/claim change, no push, no branch, no PR.
That is already the parent skill's rule; this override adds no exception
and permits none. `github-comment.md` is prepared content only — it is
handed over locally for the repository owner to read, edit, and paste (or
not) entirely at their own discretion. Every single time, regardless of
how many prior sessions did the same thing, ask for explicit, separate
permission before anything from a QA session is pasted, posted, or pushed
anywhere — a past approval never carries forward to the next session or
the next artifact.

## Knowledge base

`qa/knowledge-base/module-history.md` and `qa/knowledge-base/risk-hotspots.md`
replace `<paths.qa>/knowledge-base/{module-history,risk-hotspots}.md`.
Read both at the start of every session (parent skill step 2); append
per the parent skill's step 9 rules (module-history unconditionally,
risk-hotspots only for a genuinely new, undocumented gotcha).
