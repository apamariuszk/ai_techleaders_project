# DevMentor repo-local notes for om-prepare-test-env

Extends `om-prepare-test-env`. Repo specifics only; the parent skill's rules
still apply.

## Linux sandbox without Docker or launchd (2026-09-24)

The generated `.ai/scripts/test-env-up.sh`/`test-env-down.sh` were originally
generated on a macOS host with Docker Desktop (`docker`, `launchctl`,
BSD `date -j`/`stat -f`). On a plain Linux host with neither Docker nor
launchd, running them cold fails with `launchctl: not found` / `docker: not
found`.

**Fix baked into the scripts:** both scripts now feature-detect `docker` and
`launchctl` at run time (`HAS_DOCKER`, `HAS_LAUNCHCTL` in `test-env-up.sh`).
When absent, `test-env-up.sh` provisions a native ephemeral PostgreSQL cluster
with `initdb`/`pg_ctl` (trust auth, a throwaway data dir under
`.ai/qa/pgdata-<runId>`) instead of a Docker container, and starts the Next
dev server as a plain detached background process (`… & disown`) instead of a
launchd job. `test-env-down.sh` already had a plain-`kill` fallback for the
app process; it now also stops/removes the native Postgres cluster when no
Docker container was recorded (`services[0].pgDataDir` in the descriptor).
The macOS/Docker/launchd path is untouched — this is additive, not a
replacement.

Verified cold (~19s: npm ci + typecheck + migrate + seed + app health) and
warm (~0.08s, reused) on Debian 12 with PostgreSQL 17 client binaries
pre-installed and no Docker daemon.

**Follow-up repair (same day):** the first version of the non-launchd app-process
teardown only killed the single recorded pid. A plain `(...) &` background job in a
non-interactive `sh` script has no process group of its own (job control is off), so
that pid is npm, and `kill "$app_pid"` left npm's actual `next dev`/`next-server`
descendants running and the port still bound — teardown reported success while the
app kept serving. Fixed with a small recursive `kill_tree()` (walks `pgrep -P`
children, kills deepest-first) used in both `test-env-up.sh`'s cleanup trap and
`test-env-down.sh`'s non-launchd fallback branch. Also moved each native Postgres
instance's log file to `$pg_data_dir.log` (previously a separate, never-cleaned file
under `.ai/qa/`) so removing `$pg_data_dir` and its `.log` twin in the same `rm -rf`
leaves nothing behind. Verified with two full cold-up/down cycles: `ps aux` shows no
leftover `next dev`/`next-server` process and no leftover `pgdata-*`/`pg-*.log` files
after `test-env-down.sh` returns.

## Missing `jq` on this sandbox (2026-09-24)

The generated scripts call `jq` for every descriptor/build-cache read and
write. This sandbox's base image does not ship `jq` and has no `sudo`, so
`apt-get install jq` fails outright. Root is not required to get a working
binary — download the `.deb`s straight from the Debian mirror and extract them
with `dpkg -x` into a user-writable prefix:

```sh
mkdir -p /tmp/apt/lists /tmp/apt/cache /tmp/jqdeb /tmp/localroot
apt-get -o Dir::State::Lists=/tmp/apt/lists -o Dir::Cache=/tmp/apt/cache \
  -o Dir::State::status=/var/lib/dpkg/status update
mkdir -p /tmp/apt/archives/partial
apt-get -o Dir::State::Lists=/tmp/apt/lists -o Dir::Cache::Archives=/tmp/apt/archives \
  -o Dir::Cache=/tmp/apt/cache --download-only -y install jq
for f in /tmp/apt/archives/*.deb; do dpkg -x "$f" /tmp/localroot; done
# binary: /tmp/localroot/usr/bin/jq
# needs:  LD_LIBRARY_PATH=/tmp/localroot/usr/lib/x86_64-linux-gnu
```

Wrap it in a tiny shim and put the shim's directory first on `PATH` for the
shell that invokes `test-env-up.sh`/`test-env-down.sh` (e.g.
`export PATH="/tmp/localbin:$PATH"` before calling the script). **Do not**
drop the shim inside `node_modules/.bin` — `npm ci` (which the up-script runs
on every cold build) wipes and regenerates that directory and silently
deletes the shim mid-run, which is exactly the failure this note exists to
prevent (`jq: not found` right after the `npm ci`/typecheck step succeeds).
`/tmp` survives across tool calls in this sandbox but not across a fresh
container, so this step repeats once per sandbox lifetime, not once per repo
clone — it is an environment gap, not a repo bug, and is not something to fix
inside the generated scripts themselves.

## Headless Chrome missing shared libraries (2026-09-24)

`agent-browser install` downloads Chrome for Testing fine (no root needed),
but the binary fails to launch on this sandbox with
`error while loading shared libraries: libnspr4.so: ...` (then, once that's
fixed, `libdbus-1.so.3: ...`). `agent-browser install --with-deps` reports the
exact Debian package list it wants but then fails outright (`sudo`/`apt-get`
missing at the paths it tries): `libxcb-shm0 libx11-xcb1 libx11-6 libxcb1
libxext6 libxrandr2 libxcomposite1 libxcursor1 libxdamage1 libxfixes3 libxi6
libgtk-3-0 libpangocairo-1.0-0 libpango-1.0-0 libatk1.0-0 libcairo-gobject2
libcairo2 libgdk-pixbuf-2.0-0 libxrender1 libasound2 libfreetype6
libfontconfig1 libdbus-1-3 libnss3 libnss3-tools libnspr4 libatk-bridge2.0-0
libdrm2 libxkbcommon0 libatspi2.0-0 libcups2 libxshmfence1 libgbm1
fonts-noto-color-emoji fonts-noto-cjk fonts-freefont-ttf`.

Same fix as the `jq` gap above — download those `.deb`s with `apt-get
--download-only -o Debug::NoLocking=1 install <pkgs>` (using the same
user-writable `Dir::State::Lists`/`Dir::Cache::Archives` override) and
`dpkg -x` each into `/tmp/localroot`. The one wrinkle: some packages
(`libdbus-1-3` among them) install to `/lib/x86_64-linux-gnu/`, not
`/usr/lib/x86_64-linux-gnu/` (pre-usrmerge multiarch path baked into the
`.deb`) — put **both** on `LD_LIBRARY_PATH`, or Chrome fails on the second
missing library after the first fix looks like it worked:

```sh
export LD_LIBRARY_PATH="/tmp/localroot/usr/lib/x86_64-linux-gnu:/tmp/localroot/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
```

Verified: `agent-browser doctor --json` goes from two failing checks
(`chrome.installed`, `launch.launch`) to `"success":true` once Chrome itself
is installed (`agent-browser install`) and this `LD_LIBRARY_PATH` is set
before invoking `agent-browser` or the raw Chrome binary. Chrome launches
headless; `--no-sandbox` was not actually required once the libraries
resolved. Session-scoped fix (the extracted libs live under `/tmp`), not
something to bake into a repo script.
