Weryfikacja stanu po lekcji 13, 20.10.2026

Aplikacja została uruchomiona lokalnie, z osobną bazą PostgreSQL i atrapami OAuth, maili oraz płatności. Nie wykonywano prawdziwych płatności. Screeny pochodzą z przeglądarki; pliki PNG nie były edytowane.

1. http://localhost:3114/m/ada-legacy: w sekcji About widoczne undefined.
2. http://localhost:3114/m/mock-mentor: 25 minut daje PLN 90.00; po przełączeniu na 50 minut podsumowanie nadal PLN 90.00, mimo oferty PLN 180.00.
3. Serwer przyjął POST /api/bookings (HTTP 200). Rezerwacja znajduje się w Now and upcoming jako Waiting for payment.
Utworzono: 2026-10-20T11:46:24.63+00:00; start: 2026-10-20T12:13:00+00:00; odstęp: 26.59 min, zamiast wymaganych 120 min. Dokładny zapis: 03-rezerwacja-dowod-z-bazy.json.

Sprawdzenia kodu: typecheck OK; lint 0 błędów (1 istniejące ostrzeżenie w LandingScreen.tsx); build OK; 229 plików testowych i 2593 testy jednostkowe OK, pokrycie 100% statements/branches/functions/lines w skonfigurowanym zakresie. Zakres testów pochodzi z gałęzi nagrania i celowo nie chroni trzech ćwiczonych błędów.

Bazowy commit Epika 04: 6c86c106e487d01886bb47f2fed324b2da90be8a.
Zmiany scenariusza zaczerpnięto z istniejącego commita nagraniowego 948b8bd120ba21d8521e21b36dada4aaac3c29e9.
Seed szkoleniowy odmawia pracy w production i na bazie z istniejącymi rezerwacjami. Potwierdzono odmowę bez usunięcia istniejącej rezerwacji.

Sumy SHA-256 screenów:
14b9606c9360a20775c67a82d64318110a4d9de5ec207f554ab82002992b7978  01-brak-opisu-undefined.png
1b6f4275ba57af91236e378bca8a5b4946ec51b79fd432fe453a65d5b319a4ae  02a-cena-25-minut-90-pln.png
9aa59c4a53b68c1437fced8b88c92aca6d239ac5035500f2e79645bfee2eafb0  02b-blad-50-minut-nadal-90-pln.png
c6de227239dea1cf11bac57746a9615b1600c9983416aec064943f2a6ab191cf  03a-slot-za-mniej-niz-2h-dostepny.png
821a95a4275d3c928d7416c6a2227ca9958dbb33365f5cef1b57b0ea15a26d35  03b-przed-rezerwacja-slot-za-mniej-niz-2h.png
574e8d882c392d2a4846257f40178a533f559adc7e858184dacf5a89e24f2814  03c-zbyt-bliska-rezerwacja-na-liscie-sesji.png
