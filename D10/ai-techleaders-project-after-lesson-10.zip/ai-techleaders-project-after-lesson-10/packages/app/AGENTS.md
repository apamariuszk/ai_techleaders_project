<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

# packages/app — `@devmentor/app`

The Next.js host and composition root, and the only package that may import every other one.
`npm run dev` starts it. `npm run build` / `npm run start` run production (`NODE_ENV=production`).

## Routes

- A concept's API lives at `packages/app/src/app/api/<concept>/route.ts`, with its
  `page.tsx` under the matching persona route group. `/api/users` plus
  `packages/app/src/app/admin/users/page.tsx` is the reference every new concept copies.
- **A navigated route redirects, and a fetched route returns the envelope.** Routes a browser
  navigates to directly (the two OAuth `GET`s and the email-verification `GET`) catch their
  own failures and return a redirect `Response`, which `apiHandler` passes through. Every
  other route returns the envelope and is read through `apiCall`. Decide which kind a route
  is before writing it, because the two error paths are not interchangeable.
- Every state-changing route is JSON-only, and `apiHandler` enforces the CSRF header.
  The details are in `packages/core/AGENTS.md`.
- Touch the DB only in dynamic routes (`export const dynamic = "force-dynamic"`) and degrade
  gracefully. The app must build and boot with no database reachable.

## Three UI surfaces

Public pages (landing, `/mentors`, `/m/<slug>`, `(auth)/*`) use Tailwind utilities. The
signed-in surfaces (`(mentee)/*`, `(mentor)/*`, `/admin/*`) use shadcn-ui components from
`@devmentor/ui` inside `AppShell`. The full taxonomy is F1 in
`.ai/specs/2026-09-04-platform-primitives.md`.

## Testing pages

- Server components are invoked, not rendered. Call the exported `page`/`layout` function
  and assert on the returned tree in the default `node` environment.
- `redirect()` throws, so a guarded page needs two mocking seams. The `page.tsx` test mocks
  `packages/app/src/lib/session.ts`, asserts the tree on the authorized path, and asserts a
  sentinel throw from the mocked guard on the denied path. `session.test.ts` mocks
  `next/navigation` and asserts `redirect` was called with the expected URL. Neither
  asserts against Next internals.
- Every guarded `page.tsx` calls the guard itself instead of relying on its layout. Each one
  is therefore its own `coverage.include` entry and needs both branches covered.
