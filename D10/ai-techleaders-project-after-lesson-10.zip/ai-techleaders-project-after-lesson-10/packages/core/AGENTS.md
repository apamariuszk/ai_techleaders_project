# packages/core — `@devmentor/core`

Config (zod), logger (pino), the awilix container, domain services and the HTTP layer.
Core depends on `db` and never imports react, next or ui.

## Where things go

- Services: `packages/core/src/services/<concept>/<name>.service.ts`.
- Shared zod schemas: `packages/core/src/validators/<concept>/`, only when something needs them.
- Events: IDs follow `concept.entity.action` (e.g. `bookings.booking.created`) and are emitted
  through the typed emitter in `packages/core/src/events`, which is registered on the
  `Cradle`. Events are in-process only; there is no queue or worker. The payments-port and
  emitter patterns are in `.ai/specs/2026-09-01-engineering-standards.md`.
- Request-scoped work goes through `withScope(fn)`. It opens an awilix scope with a forked
  `EntityManager` and disposes it afterward.

## HTTP layer (`packages/core/src/http/`)

- `errors.ts` holds the typed `AppError` hierarchy. `apiHandler.ts` wraps a route: it catches
  `AppError`s, maps them to a status and a JSON envelope, and logs unexpected failures.
  `makeCrudRoute.ts` takes a schema and a service and returns `{ GET, POST, PUT, DELETE }`
  for plain CRUD resources. `auth.ts` has `requireSession`, `requireRole` and the
  ownership assertions.
- Routes use `makeCrudRoute`/`apiHandler`, never a bare `try/catch` + `NextResponse.json`.
  Services throw typed `AppError`s and return DTOs. They never build responses.
- The envelope (`{ ok, data }` / `{ ok, error }`) is a shape convention, not a shared type.
  Core declares its own copy, and so does `packages/ui/src/backend/api`, because ui must not
  import core.
- `apiHandler` requires the CSRF header `x-devmentor-request` on every method except
  `GET`, `HEAD` and `OPTIONS`, so `makeCrudRoute`'s mutating verbs inherit the check. The
  only opt-out, `apiHandler(logic, { csrf: false })`, is reserved for the payment webhook,
  which verifies a signature (`BACKWARD_COMPATIBILITY.md` §7).
- Collection routes are non-dynamic, so Next passes no `params`. CRUD helpers must guard
  `ctx.params` before reading it.

## Never `instanceof` an `AppError`

Next evaluates `@devmentor/core` once per module graph (SSR/RSC and each Route Handler), while
`getContainer()` shares one container through `globalThis`. As a result, the class a service
threw is often not the class the route imported. `isAppError` is therefore a brand check
(`Symbol.for`, cross-realm). See `APP_ERROR_BRAND` in `packages/core/src/http/errors.ts`.
Discriminate on `code`. Any other cross-graph identity test needs `Symbol.for`, a string tag
or a `globalThis` singleton. The background is in the 2026-09-10 entry in `.ai/lessons.md`.

## Config and logging

- `packages/core/src/config/env.ts` is the app's only env reader. Keep its
  `DATABASE_URL`-over-`DB_*` precedence in step with `packages/db/src/env.ts` and
  `scripts/setup/steps.mjs`.
- `createLogger` (`packages/core/src/logger.ts`) censors `password`, `passwordHash`,
  `token`, `authorization` and `cookie` at the top level and up to two levels below any key.
  Treat that as a backstop only: log ids and outcomes, never credentials. Redaction cannot
  see inside composed strings, so strip query strings from URLs with
  `packages/core/src/http/safe-url.ts` before logging. `fetchJson` never passes a request
  body or request headers to a logger.
