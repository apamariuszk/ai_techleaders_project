#!/usr/bin/env bash
# <project_root>/.claude/hooks/pre-tool-use.sh
input=$(cat)
cmd=$(echo "$input" | jq -r '.tool_input.command // empty')

case "$cmd" in
  *"curl"*"| sh"*|*"curl"*"|sh"*|*"rm -rf /"*|*"cat .env"*|*"~/.ssh"*|*"~/.aws"*)
    echo "Zablokowane przez politykę zespołu: $cmd" >&2
    exit 2 ;;
esac
exit 0