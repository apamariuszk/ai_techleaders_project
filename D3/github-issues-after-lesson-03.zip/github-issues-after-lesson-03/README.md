# Odtworzenie GitHub Issues po lekcji 03

Ta eksperymentalna paczka zawiera stan GitHub Issues projektu DevMentor zapisany po
lekcji 03. Importer tworzy zgłoszenia, etykiety i komentarze w repozytorium
uczestnika. Nie modyfikuje kodu i nie odtwarza pull requestów.

## Zawartość

- `issues.json` – 30 issues, 7 używanych etykiet i 32 komentarze,
- `restore-issues.sh` – bezpieczny importer oparty na `gh` i `jq`,
- `skills/restore-github-issues/SKILL.md` – instrukcja dla agenta AI,
- `pull-requests-reference.json` – zrzut 8 pull requestów wyłącznie do wglądu.

Snapshot pochodzi z prywatnego repozytorium
`open-mercato/ai_techleaders_project`, z taga `after-lesson-03` i commita
`040791e1f2974b6b4e1193a108fd8f885ee8aabc`.

## Wymagania

- GitHub CLI `gh`, zalogowane przez `gh auth login`,
- `jq`,
- repozytorium docelowe, w którym nie ma żadnych issues ani pull requestów.

## Użycie

Najpierw tylko sprawdź warunki:

```bash
./restore-issues.sh --repo TWOJ-LOGIN/TWOJE-REPO --check
```

Jeśli kontrola przejdzie, uruchom import:

```bash
./restore-issues.sh --repo TWOJ-LOGIN/TWOJE-REPO --yes
```

Skrypt zapisze w bieżącym katalogu plik `issue-number-map.json`. GitHub używa
wspólnej numeracji dla issues i pull requestów, dlatego numery w repozytorium
uczestnika mogą różnić się od numerów źródłowych. Mapa zachowuje to powiązanie.

## Zabezpieczenia

Importer kończy pracę przed pierwszą zmianą, gdy znajdzie choć jedno issue albo
jeden pull request, niezależnie od ich stanu. Nie ma opcji `--force`. Istniejące
etykiety są pomijane, a nie nadpisywane. Gdy import zostanie przerwany w połowie,
nie uruchamiaj go ponownie w tym samym repozytorium. Użyj zapisanej mapy do
sprawdzenia utworzonych zgłoszeń.

## Dlaczego pull requesty są tylko referencją

Odtworzenie pull requestu wymaga też odtworzenia jego commitów, gałęzi bazowej i
gałęzi źródłowej. Sam JSON nie wystarcza do wiarygodnego importu. Dlatego pierwsza
wersja paczki zachowuje ich metadane do analizy, ale celowo ich nie tworzy.
