#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SNAPSHOT_FILE="$SCRIPT_DIR/issues.json"
TARGET_REPO=""
MODE=""
MAP_FILE="$PWD/issue-number-map.json"

usage() {
  printf '%s\n' \
    "Użycie:" \
    "  ./restore-issues.sh --repo OWNER/REPO --check" \
    "  ./restore-issues.sh --repo OWNER/REPO --yes [--map PLIK]" \
    "" \
    "Opcje:" \
    "  --repo OWNER/REPO  Repozytorium docelowe. Jeśli pominiesz, skrypt użyje bieżącego repo." \
    "  --check            Tylko sprawdź wymagania i pusty stan repozytorium." \
    "  --yes              Potwierdź utworzenie issues i komentarzy." \
    "  --map PLIK         Zapisz mapę numerów pod wskazaną ścieżką." \
    "  --help             Pokaż tę pomoc."
}

die() {
  printf 'BŁĄD: %s\n' "$1" >&2
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo)
      [[ $# -ge 2 ]] || die "Brakuje wartości po --repo."
      TARGET_REPO="$2"
      shift 2
      ;;
    --check)
      [[ -z "$MODE" ]] || die "Wybierz tylko jeden tryb: --check albo --yes."
      MODE="check"
      shift
      ;;
    --yes)
      [[ -z "$MODE" ]] || die "Wybierz tylko jeden tryb: --check albo --yes."
      MODE="restore"
      shift
      ;;
    --map)
      [[ $# -ge 2 ]] || die "Brakuje wartości po --map."
      MAP_FILE="$2"
      shift 2
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      die "Nieznany argument: $1"
      ;;
  esac
done

[[ -n "$MODE" ]] || die "Najpierw uruchom --check, a import potwierdź przez --yes."
command -v gh >/dev/null 2>&1 || die "Nie znaleziono polecenia gh. Zainstaluj GitHub CLI."
command -v jq >/dev/null 2>&1 || die "Nie znaleziono polecenia jq."
[[ -f "$SNAPSHOT_FILE" ]] || die "Nie znaleziono snapshotu: $SNAPSHOT_FILE"

jq -e '
  .schema_version == 1 and
  (.source_repository | type == "string") and
  (.issues | type == "array") and
  all(.issues[]; (.source_number | type == "number") and (.title | type == "string"))
' "$SNAPSHOT_FILE" >/dev/null || die "Plik issues.json nie spełnia oczekiwanego schematu."

gh auth status >/dev/null 2>&1 || die "GitHub CLI nie jest zalogowane. Uruchom: gh auth login"

if [[ -z "$TARGET_REPO" ]]; then
  TARGET_REPO="$(gh repo view --json nameWithOwner --jq '.nameWithOwner')" || \
    die "Nie udało się rozpoznać repozytorium. Podaj --repo OWNER/REPO."
fi

TARGET_REPO="$(gh repo view "$TARGET_REPO" --json nameWithOwner --jq '.nameWithOwner')" || \
  die "Nie udało się odczytać repozytorium docelowego."

issue_count="$(gh issue list --repo "$TARGET_REPO" --state all --limit 1 --json number --jq 'length')"
pr_count="$(gh pr list --repo "$TARGET_REPO" --state all --limit 1 --json number --jq 'length')"

if [[ "$issue_count" != "0" || "$pr_count" != "0" ]]; then
  die "Repozytorium $TARGET_REPO nie jest puste: issues=$issue_count, pull requesty=$pr_count. Skrypt niczego nie zmienił."
fi

source_repo="$(jq -r '.source_repository' "$SNAPSHOT_FILE")"
source_ref="$(jq -r '.source_ref' "$SNAPSHOT_FILE")"
source_count="$(jq -r '.issues | length' "$SNAPSHOT_FILE")"

printf 'Repozytorium docelowe: %s\n' "$TARGET_REPO"
printf 'Snapshot: %s @ %s, issues: %s\n' "$source_repo" "$source_ref" "$source_count"
printf 'Kontrola bezpieczeństwa: brak issues i pull requestów.\n'

if [[ "$MODE" == "check" ]]; then
  printf 'Wynik: można wykonać import poleceniem z --yes.\n'
  exit 0
fi

[[ ! -e "$MAP_FILE" ]] || die "Plik mapy już istnieje: $MAP_FILE. Wskaż inną ścieżkę przez --map."

work_dir="$(mktemp -d "${TMPDIR:-/tmp}/restore-github-issues.XXXXXX")"
cleanup() {
  rm -rf "$work_dir"
}
trap cleanup EXIT

existing_labels="$(gh label list --repo "$TARGET_REPO" --limit 200 --json name --jq '.[].name')"

while IFS= read -r label; do
  label_name="$(jq -r '.name' <<<"$label")"
  label_color="$(jq -r '.color' <<<"$label")"
  label_description="$(jq -r '.description // ""' <<<"$label")"

  if printf '%s\n' "$existing_labels" | grep -Fxq "$label_name"; then
    printf 'Etykieta już istnieje, pomijam: %s\n' "$label_name"
  else
    gh label create "$label_name" --repo "$TARGET_REPO" --color "$label_color" \
      --description "$label_description"
    printf 'Utworzono etykietę: %s\n' "$label_name"
  fi
done < <(jq -c '.labels[]' "$SNAPSHOT_FILE")

jq -n \
  --arg source_repository "$source_repo" \
  --arg destination_repository "$TARGET_REPO" \
  --arg imported_at "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  '{schema_version: 1, source_repository: $source_repository, destination_repository: $destination_repository, imported_at: $imported_at, issues: {}}' \
  > "$MAP_FILE"

while IFS= read -r issue; do
  source_number="$(jq -r '.source_number' <<<"$issue")"
  title="$(jq -r '.title' <<<"$issue")"
  source_url="$(jq -r '.source_url' <<<"$issue")"
  body_file="$work_dir/issue-$source_number.md"

  {
    jq -r '.body // ""' <<<"$issue"
    printf '\n\n---\nOdtworzono ze snapshotu issue #%s: %s\n' "$source_number" "$source_url"
  } > "$body_file"

  label_args=()
  while IFS= read -r issue_label; do
    [[ -n "$issue_label" ]] && label_args+=(--label "$issue_label")
  done < <(jq -r '.labels[]' <<<"$issue")

  created_url="$(gh issue create --repo "$TARGET_REPO" --title "$title" --body-file "$body_file" "${label_args[@]}")"
  target_number="${created_url##*/}"
  printf 'Issue #%s → #%s\n' "$source_number" "$target_number"

  while IFS= read -r comment; do
    comment_file="$work_dir/comment-$source_number.md"
    comment_author="$(jq -r '.author // "nieznany"' <<<"$comment")"
    comment_date="$(jq -r '.created_at' <<<"$comment")"
    comment_url="$(jq -r '.source_url' <<<"$comment")"
    {
      printf '> Oryginalny komentarz: @%s, %s, %s\n\n' "$comment_author" "$comment_date" "$comment_url"
      jq -r '.body // ""' <<<"$comment"
    } > "$comment_file"
    gh issue comment "$target_number" --repo "$TARGET_REPO" --body-file "$comment_file" >/dev/null
  done < <(jq -c '.comments[]' <<<"$issue")

  if [[ "$(jq -r '.state' <<<"$issue")" == "CLOSED" ]]; then
    gh issue close "$target_number" --repo "$TARGET_REPO" >/dev/null
  fi

  next_map="$work_dir/issue-number-map.json"
  jq \
    --arg source_number "$source_number" \
    --argjson target_number "$target_number" \
    --arg url "$created_url" \
    '.issues[$source_number] = {target_number: $target_number, url: $url}' \
    "$MAP_FILE" > "$next_map"
  mv "$next_map" "$MAP_FILE"
done < <(jq -c '.issues[]' "$SNAPSHOT_FILE")

restored_count="$(gh issue list --repo "$TARGET_REPO" --state all --limit 200 --json number --jq 'length')"
[[ "$restored_count" == "$source_count" ]] || \
  die "Import zatrzymał się przy $restored_count z $source_count issues. Zachowaj plik mapy i nie uruchamiaj importu ponownie."

printf 'Gotowe. Odtworzono %s issues.\n' "$restored_count"
printf 'Mapa numerów: %s\n' "$MAP_FILE"
