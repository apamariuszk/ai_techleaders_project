---
name: restore-github-issues
description: Odtwórz szkoleniowy snapshot GitHub Issues w pustym repozytorium za pomocą dołączonego skryptu, z kontrolą istniejących issues i pull requestów przed każdą zmianą.
---

# Odtwarzanie GitHub Issues

Użyj dołączonego `restore-issues.sh`. Nie przepisuj importera ani nie twórz issues
ręcznie, bo skrypt zachowuje etykiety, komentarze i mapę zmienionych numerów.

## Procedura

1. Ustal repozytorium docelowe w formacie `OWNER/REPO` i pokaż je użytkownikowi.
2. Sprawdź, czy `gh` jest zalogowane i czy `jq` jest dostępne.
3. Uruchom `./restore-issues.sh --repo OWNER/REPO --check`.
4. Jeśli kontrola wykryje choć jedno issue lub jeden pull request, zatrzymaj się.
   Nie usuwaj istniejących danych i nie szukaj obejścia.
5. Przed zmianą repozytorium uzyskaj potwierdzenie użytkownika.
6. Uruchom `./restore-issues.sh --repo OWNER/REPO --yes`.
7. Podaj liczbę utworzonych issues i ścieżkę do `issue-number-map.json`.

Nie używaj opcji ani modyfikacji omijających kontrolę pustego repozytorium.
Pull requesty w `pull-requests-reference.json` są materiałem referencyjnym i nie
wolno ich odtwarzać automatycznie z tej paczki.
