# Stan po lekcji 14: poprawka reguły dwóch godzin

Baza: szkoleniowy stan po lekcji 13, commit 983b89830968d32d114b2875f54b4925486626cd. Poprawka i testy przeniesione z rzeczywistego commita PR #68: 648feefad4e65ff6ef0a1d7f262aeded4df422bd. Zmiany aplikacji dotyczą tylko dwóch serwisów czasu i ich testów; błędy opisu i ceny pozostają.

## Weryfikacja

- Nowe pliki testów na starym kodzie w osobnym worktree: 4 nieudane asercje, 82 testy zielone. Błędy dotyczą oznaczenia dostępności i odrzucenia rezerwacji za 90 minut oraz granicy dwóch godzin. Nie są to błędy importu ani środowiska.
- Te same pliki na poprawionym kodzie: 86/86 zielonych testów.
- Cały zestaw: 229 plików testowych, 2597 testów OK, pokrycie 100% w skonfigurowanym zakresie.
- Typecheck OK, lint 0 błędów i 1 istniejące ostrzeżenie o img w prototypie, build OK.
- Przeglądarka: sloty za mniej niż dwie godziny oznaczone jako niedostępne, przyciski disabled. Surowy screen jest w .ai/qa/lesson-14-fixed-verification.
- API na tej samej aplikacji i osobnej bazie: zbyt bliski termin zwraca 422 validation_failed; termin za ponad dwie godziny zwraca 200. Atrapy OAuth, płatności i poczty, bez prawdziwych płatności.

Dokładne wyniki RED/GREEN i odpowiedzi HTTP znajdują się w .ai/qa/lesson-14-fixed-verification. Brak sekretów i cookies w artefaktach.
