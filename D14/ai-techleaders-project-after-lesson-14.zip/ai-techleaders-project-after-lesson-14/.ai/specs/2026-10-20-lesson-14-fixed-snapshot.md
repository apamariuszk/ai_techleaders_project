# Snapshot po lekcji 14

## Cel

Dostarczyć stan po naprawie czasu z lekcji14 bez naprawiania opisu i ceny, które w nagraniu pozostają na później.

## Podejście

Na bazie szkoleniowego snapshotu po lekcji13 przenosimy wyłącznie dwa serwisy i ich testy z commita PR68. Dodajemy instrukcję uruchomienia testów i dowody porównania tej samej regresji na starej i poprawionej implementacji.

## Kryteria odbioru

90 minut odrzucane, dokładnie dwie godziny akceptowane, o1ms mniej odrzucane. Testy czerwone przed i zielone po. Przeglądarka blokuje bliskie sloty; API zwraca422 dla bliskiego i200 dla odległego. Epik04 pozostaje w paczce.

## Poza zakresem

Pozostałe błędy opisu i ceny, modyfikacja gałęzi master i wdrożeń.
