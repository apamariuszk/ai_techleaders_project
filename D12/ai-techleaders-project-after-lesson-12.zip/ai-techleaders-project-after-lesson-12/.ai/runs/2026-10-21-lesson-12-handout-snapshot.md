# Lesson 12 handout source snapshot

Date: 2026-10-21

## Request and scope

Prepare the downloadable DevMentor source state after lesson 12. Include the
integration tests and paired Markdown scenarios developed in its recordings, and
the project-local extension of the integration-testing skill. Verify the actual
source before creating the ZIP and TGZ downloads. No newer course epics or the
intentional regression branch are included.

## Provenance

- Historical application base: `d389c38d09488fddcec43bc5c98b9555467da42e`.
  Its ancestry includes the mentor technology publication guard, its regression
  test, and the reviewed E01/E02 scenario expansion.
- Restored unchanged from `cc494cf672d3581f30b97fc32030d9242f202882`:
  `.ai/skills/om-integration-tests/SKILL.md` and
  `.ai/skills/om-integration-tests/references/best-practices-integration-tests.md`.
  These two teaching artifacts were absent from the merged historical base.
  The skill's original `@../../../.agents/skills/om-integration-tests/SKILL.md`
  import resolves to the bundled shared skill.
- Checked against the six lesson 12 recording summaries. In particular,
  `TC-MENTOR-PROFILE-001` refuses publication without a technology and verifies
  the unchanged database state. The final expansion covers E01/E02 accounts,
  sessions, roles, invitations, mentor profiles, availability and prices.
- Removed stale tracked `.ai/qa/test-env-app.log` and
  `.ai/qa/test-env-build-cache.json`; added both runtime paths to `.gitignore`.
  Durable historical QA scenario documentation and sanitized evidence remain.
- No application production code or test assertions were changed for this snapshot.

## Verification

Environment: macOS arm64, Node `24.19.0`, npm `11.17.0`, Docker `29.1.3`,
repository-pinned `agent-browser` `0.36.0`, installed Chrome `156.0.8078.47`.

- `npm ci`: passed using the existing lockfile.
- `npm run test:browser:install`: passed.
- `npm run lint`: passed, no errors.
- `npm run typecheck`: passed.
- `npm run test:unit:coverage`: 150 files and 1,742 tests passed; statements,
  branches, functions and lines each have 100% coverage.
- `npm run test:integration`: 14 files and 85 tests passed in 78.63 seconds,
  using a fresh Testcontainers PostgreSQL database and a production build.
  This also verifies migrations, repeated seeding, production build and browser
  scenarios, including `TC-MENTOR-PROFILE-001`.
- All 27 `.ai/qa/{AREA}/*.md` scenario documents' relative implementation
  links resolve; the skill import resolves and its two files match their source
  commit byte for byte.

## Packaging

After successful verification, both handout downloads are produced with
`git archive` from this same local commit, with the common root directory
`ai-techleaders-project-after-lesson-12/`. The handout records their SHA-256 sums.
Only tracked source and durable records are archived; no `.git`, local secret
files, installed dependencies, generated application build, coverage output or
integration runtime output is included. ZIP/TGZ file payloads are compared.

## Outcome

The lesson 12 source is verified and ready to archive. Archive payload parity and
SHA-256 integrity are checked by the handout packaging process after this commit
exists; the handout records the final source commit and download checksums.
No remote source-repository changes are made by this snapshot preparation.
